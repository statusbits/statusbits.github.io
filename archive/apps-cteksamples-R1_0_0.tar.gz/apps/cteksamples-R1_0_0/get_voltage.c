#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>

#define ADC_READ 1

int main(int argc, char **argv)
{
  int fd=-1, val;
  double x;


  if((fd=open("/dev/at91_adc",O_RDONLY))<0){
    fprintf(stderr, "can't open ADC\n");
    exit(1);
  }


  val=ioctl(fd,ADC_READ,0);
  if(val<0){
    fprintf(stderr, "read error %d\n",val);
    exit(1);
  }

  x = val;
  x = (x * 40) / 1024;
  printf("%.2lfVdc\n", x);
  close(fd);
    
  return 0;
}
