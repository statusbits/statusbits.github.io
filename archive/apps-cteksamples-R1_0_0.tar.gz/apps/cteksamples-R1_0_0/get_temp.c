#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>

#define ADC_READ 1

int main(int argc, char **argv)
{
  int fd=-1, val;
  double x;


  if((fd=open("/dev/at91_adc",O_RDONLY))<0){
    fprintf(stderr, "can't open ADC\n");
    exit(1);
  }


  val=ioctl(fd,ADC_READ,1);
  if(val<0){
    fprintf(stderr, "read error %d\n",val);
    exit(1);
  }

  x = val;
  x = ((x * 0.0024) - 1.8535) / -0.0117 ;
  printf("%.2lfC  %.2lfF\n", x, ((x * 1.8) + 32));
  close(fd);
    
  return 0;
}
