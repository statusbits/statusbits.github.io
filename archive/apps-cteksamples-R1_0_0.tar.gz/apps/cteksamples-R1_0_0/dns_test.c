#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <termios.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <netdb.h>
#include <sys/socket.h>
#include <arpa/inet.h>

extern int h_errno;

struct hostent *hid;
char   adr[20];
char  *pt;


int main(int argc, char **argv)
{
  if(argc == 2)
  {
     hid = gethostbyname(argv[1]);
     if(hid == NULL)
     {
         if(h_errno == HOST_NOT_FOUND)
            printf("ERROR %d: Host Not Found %s \n", h_errno, argv[1]);
         else if((h_errno == NO_ADDRESS) || (h_errno == NO_DATA))
            printf("ERROR %d: No Address or No Data %s\n", h_errno, argv[1]);
         else if(h_errno == NO_RECOVERY)
            printf("ERROR %d: No Recovery %s\n", h_errno, argv[1]);
         else if(h_errno == TRY_AGAIN)
            printf("ERROR %d: Try Again Later %s\n", h_errno, argv[1]);
         else
            printf("ERROR %d: Unknown Error Code %s\n", h_errno, argv[1]);
     }
     else
     {
        pt = inet_ntop(AF_INET, hid->h_addr_list[0], adr, sizeof(adr));
        printf("GOOD RESULTS %s %s \n", adr, hid->h_name);
     }
   }
   else
      printf("PARAMETER ERROR \n");
  exit (EXIT_SUCCESS);
}
