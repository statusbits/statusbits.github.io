/* vFTPd (Virtual FTP daemon)
 *
 * Written by Bjorn Wesen
 * Copyright (C) 1999-2005 Axis Communications AB
 *
 * This file is distributed under the Gnu Public License (GPL),
 * please see the file LICENSE for further information.
 *
 *
 *
 * Required commands:
 *
 * USER <username>
 * PASS <password>
 * CWD <new working directory>
 * CDUP (cd ..)
 * QUIT
 * PORT h1,h2,h3,h4,p1,p2  (host, port)
 * PASV
 * RETR
 * STOR
 * DELE
 * RMD (remove directory)
 * MKD (make directory)
 * PWD
 * LIST <dir>
 * NOOP
 * TYPE binary/ascii
 * RNFR (rename from file)
 * RNTO (rename to file)
 *
 * Responses:
 * 220 hostname FTP server ready.
 * 221 Goodbye.
 * 331 Password required for user.
 * 350 File exists, ready for destination name
 * 230 User xxx logged in.
 * 250 Command successful
 * 257 Informative response
 * 502 Command not implemented.
 * 530 Incorrect login
 * 1yz   Positive Preliminary reply
 * 2yz   Positive Completion reply
 * 3yz   Positive Intermediate reply
 * 4yz   Transient Negative Completion reply
 * 5yz   Permanent Negative Completion reply
 */

#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <signal.h>
#include <syslog.h>
#include <crypt.h>
#include <fcntl.h>
#include <netdb.h>

#include "vftpd.h"
#include "virtual_target.h"
#include "ls.h"

#define DEBUG(x) 
#undef max
#define max(x,y) ((x) > (y) ? (x) : (y))

#define ARG_AF_INET  1
#define ARG_AF_INET6 2

#ifdef A_ACCESS_LOG
#include <axaccess.h>
#define PROT_STR        "FTP"
#endif

/* This define sholud be defined in <bits/in.h> but in older versions of
   glibc (e.g. 2.2.3) is this define missing. */
#ifndef IPV6_V6ONLY
#define IPV6_V6ONLY 26
#endif

/* FTP commands */
const char *c_user  = "USER";
const char *c_quit  = "QUIT";
const char *c_pass  = "PASS";
const char *c_syst  = "SYST";
const char *c_help  = "HELP";
const char *c_port  = "PORT";
const char *c_pasv  = "PASV";
const char *c_list  = "LIST";
const char *c_nlst  = "NLST";
const char *c_retr  = "RETR";
const char *c_stor  = "STOR";
const char *c_type  = "TYPE";
const char *c_mkd   = "MKD";
const char *c_rmd   = "RMD";
const char *c_dele  = "DELE";
const char *c_pwd   = "PWD";
const char *c_cwd   = "CWD";
const char *c_site  = "SITE";
const char *c_cdup  = "CDUP";
const char *c_rnfr  = "RNFR";
const char *c_rnto  = "RNTO";
const char *c_noop  = "NOOP";
const char *c_eprt  = "EPRT";
const char *c_epsv  = "EPSV";

/* SITE commands */
const char *c_chmod  = "CHMOD";
const char *c_reboot = "REBOOT";

/* FTP response codes */
const char *r_shutdown		= "150-Shutting down processes.\r\n";
const char *r_openingdata	= "150 Opening data connection.\r\n";
const char *r_hello		= "220 Simple FTPd welcomes you.\r\n";
const char *r_goodbye		= "221 Goodbye.\r\n";
const char *r_loggedin		= "230 User logged in, proceed.\r\n";
const char *r_help		= "214-The following commands are implemented.\r\n"
				"   USER	   QUIT	   PASS	   SYST	   HELP	   PORT	   PASV	   LIST\r\n"
				"   NLST	   RETR	   STOR	   TYPE	   MKD	   RMD	   DELE	   PWD\r\n"
				"   CWD	   SITE	   CDUP	   RNFR	   RNTO	   NOOP    EPRT    EPSVr\n"
				  "214 End of list.\r\n";
const char *r_sitehelp		= "214-The following SITE commands are implemented.\r\n"
				  "   CHMOD   REBOOT\r\n"
				  "214 End of list.\r\n";
const char *r_nohelp		= "214 There is no help for that command.\r\n";
const char *r_virtexec		= "214-Virtual target execution.\r\n";
const char *r_virtexit		= "214 Virtual target exit.\r\n";
const char *r_system		= "215 UNIX Type: L8\r\n";
const char *r_success		= "250 Command successful.\r\n";
const char *r_okay		= "200 Command okay.\r\n";
const char *r_trcomplete	= "226 Transfer complete.\r\n";
const char *r_fileexists	= "350 File exists, ready for destination name.\r\n";
const char *r_userok		= "331 User name okay, need password.\r\n";
const char *r_too_many_clients	= "421 Too many clients connected\r\n";
const char *r_cantopen		= "425 Cannot open data connection.\r\n";
const char *r_error		= "500 Syntax error.\r\n";
const char *r_badseq		= "503 Bad sequence of commands.\r\n";
const char *r_notimpl		= "502 Command not implemented.\r\n";
const char *r_protonotsupp      = "522 Network protocol not supported, use (1,2)\r\n";
const char *r_nosuchfile	= "550 No such file or directory.\r\n";
const char *r_noaccess		= "550 Access denied.\r\n";
const char *r_notadir		= "550 Not a directory.\r\n";
const char *r_outofspace	= "550 Device out of space.\r\n";
const char *r_outofmem		= "550 Out of memory.\r\n";
const char *r_unknownerror	= "550 Unknown error.\r\n";
const char *r_badlogin		= "530 Login incorrect.\r\n";
const char *r_use_i_mode	= "550 Must use 'binary' mode (TYPE I).\r\n";
const char *r_unknown_mode	= "550 Unknown mode.\r\n";
const char *r_bad_file		= "550 Bad file.\r\n";
const char *r_notperm		= "550 Not permitted\r\n";

/* only root can login if set by command option -r */
static int root_login_only = 0;

/* default daemon mode, turn off by command option -n */
static int daemon_mode = 1;

/* default maximum number of available connections */
static int max_connections = -1;

/* QoS dsfield for control and data socket */
static int qos_ctrl_dsfield = 0;
static int qos_data_dsfield = 0;

/* VLAN user-priority for control and data socket */
static int qos_ctrl_dot1prio = 0;
static int qos_data_dot1prio = 0;

/* number of active connections */
static int active_connections = 0;

/* binary (I) or ascii (A) */
static char data_format;

/* The port used for the control channel. Port ctrl_port-1 is used for the
   data channel */
static int ctrl_port;

/* contains the welcome banner shown each time the ftp daemon forks */
static char banner[BANNER_LEN];

/* SIGTERM flag */
static int terminate = 0;

/* return 0 if signal initialisation succeeds or -1 */
static int signals_init(void);

/* handle process termination, iterate and close file descriptors */
static void sigchld(int dummy);

/* abort on fatal error */
static void sigabort(int signo);

/* may want to wait for transfers in progress */
static void sigterm(int dummy);

/* step beyond whitespace in the beginning of a string and return
   first non-whitespace character or \0 */
static char *gobble_space(char *c);

/* validate IP address and port */
static int validate_ip_address(struct s_client *client);

/* provide some basic help */
static void do_help(int fd, char *args);

/* change access permissions to what is hidden in args,
   e.g. site chmod 775 foo */
static void do_site(int fd, char *args);

/* change current working directory to dirname without checking access
   permissions */
static void do_chdir(int fd, const char *dirname);

/* handle a ftp session where the fd is the established socket
   identified by the remote_addr */
static void ftpd_main(int fd, struct sockaddr_storage *remote_addr);

/* return the default banner r_hello if the banner file does not exist */
char *set_banner(void);

/* read a command from the client until it ends with a newline
   if an error occurs, return -1 */
static int get_command(int fd, char *buf);

/* check if login is correct; if so return 0, uid and gid.
   on failure return -1 */
static int check_login(char* user, char* pass, uid_t *uid, gid_t *gid);

/* send an error response to the client on an open control connection */
static void send_error_resp(int fd);

/* list files in directory dir based on the content in simple */
static void do_list(const char *dir, int fd, struct s_client *client, int simple);

/* validate the client IP address and store it with the client port in
   struct s_client from the string command. Respond with okay or
   unknown error to the client */
static void handle_port_cmd(int fd, const char *command, struct s_client *client);

/* opens a passive data connection on file descriptor fd
   and listens. Returns the file descriptor or -1 on fatal
   error. */
static int open_passive_data_connection(int af);

/* open a data connection to the client and return the file
   descriptor fd or -1 on fatal error */
static int open_data_connection(struct s_client *client);

/* write to control connection fd when the command buf of length len
   is not a trivial command listed */
int write_to_fd(int fd, const char *buf, int len);

/* opens a passive data connection and ignores the return value,
   closes the previously opened client connection and replaces it with
   the passive one. Respond with entering passive mode or unknown error. */
static void handle_pasv_cmd(int fd, struct s_client *client);

/* validate the client IPv4 or IPv6 address and store it with the
   client port in struct s_client from the string command. Respond
   with okay, network protocol not supported or unknown error to the
   client. */
static void handle_eprt_cmd(int fd, char *command, struct s_client *client);

/* opens a passive data connection. Respond with entering passive mode,
   network protocol not supported, syntax error or unknown error. */
static void handle_epsv_cmd(int fd, char *command, struct s_client *client);

/* open fname as a virtual or regular file and send local file content
   to the client in binary or ASCII format. Response codes are sent
   and it returns or exits on fatal errors */
static void do_retr(char *fname, int fd, struct s_client *client);

/* open fname as a virtual or regular file and receive local file content
   from the client in binary or ASCII format. Response codes are sent
   and it returns or exits on fatal errors */
static void do_stor(char *fname, int fd, struct s_client *client);

/* set QoS socket options  */
static void qos_setup_socket(int af, int sock, int dsfield, int prio);

/* return the address family based on the given argument
   return -1 if not supported */
static int ftp_to_inet_addr_family(int argument);

/* Setup the master listening socket, wait for connections and invoke
   ftpd_main in a child whenever a connection comes. */
int
main(int argc, char **argv)
{
	const char opt[] = "rdnm:q:Q:";
	int opt_c;
	int dont_close_fd = 0;
	struct sockaddr_storage remote_addr;
	int remote_addrlen;
	fd_set rfds;
	int true = 1;
	int syslog_option = LOG_PID;

	/* parse the command line options */
	for (;;) {
		opt_c = getopt(argc, argv, opt);
		/* last argument may be optional port number historically */
		if (opt_c == -1) {
			if (optind < argc) {
				ctrl_port = atoi(argv[optind]);
			}
			break;
		}
		/* any known arguments */
		switch (opt_c) {
		case 'r':
			root_login_only = true;
			break;
		case 'd':
			syslog_option |= LOG_PERROR;
			dont_close_fd = -1;
			break;
		case 'n':
			daemon_mode = 0;
			break;
		case 'm':
			max_connections = atoi(optarg);
			break;
		case 'q':
			{
				char *endptr;
				qos_ctrl_dsfield = strtoul(optarg, &endptr, 0);
				if (endptr != optarg && endptr[0] != '\0') {
					qos_ctrl_dot1prio = strtoul(endptr + 1, NULL, 0);
				}
			}
			break;
		case 'Q':
			{
				char *endptr;
				qos_data_dsfield = strtoul(optarg, &endptr, 0);
				if (endptr != optarg && endptr[0] != '\0') {
					qos_data_dot1prio = strtoul(endptr + 1, NULL, 0);
				}
			}
			break;
		default:
			break;
		}
	}

	/* generic user level messages prefixed by name and pid */
	openlog(PROGRAM_NAME, syslog_option, LOG_FTP);
	syslog(LOG_INFO, "Starting vftpd 0.01");

	/* execute as daemon */
	DEBUG(dont_close_fd = -1);
	if (daemon_mode == true) {
		if (daemon(0, dont_close_fd) < 0) {
			syslog(LOG_ERR, "Failed: daemon. %m");
			exit(EXIT_FAILURE);
		}
	}

	if (signals_init() < 0) {
		syslog(LOG_ERR, "Failed: signals_init.");
		exit(EXIT_FAILURE);
	}

	/* listen to the chosen ftp port and accept one connection only */
	if (ctrl_port <= 0 || ctrl_port >= 65536) {
		ctrl_port = IPPORT_FTP;
	}

	{
#define MAXSOCK 2
		struct addrinfo hints, *res, *aip;
		int error, ctrlfd[MAXSOCK], nsock=0;
		char service[6];
		int i;

		snprintf(service, sizeof(service) - 1, "%u", ctrl_port);
		service[sizeof(service) - 1] = '\0';

		memset(&hints, 0, sizeof(hints));
		hints.ai_flags = AI_PASSIVE;
		hints.ai_family = AF_UNSPEC;
		hints.ai_socktype = SOCK_STREAM;

		error = getaddrinfo(NULL, service, &hints, &res);
		if (error != 0) {
			syslog(LOG_ERR, "Failed to getaddrinfo %s", gai_strerror(error));
		}
		for (aip=res; aip && nsock < MAXSOCK; aip=aip->ai_next) {
			/* Ignore LOCAL sockets.  Work-around for buggy 
			 * getaddrinfo in at least glibc 2.2.3. */
			if (aip->ai_family == AF_LOCAL)
				continue;

			ctrlfd[nsock] = socket(aip->ai_family,
					       aip->ai_socktype,
					       aip->ai_protocol);
			if (ctrlfd[nsock] < 0) {
				/* Skip the errors and try the next one until
				 * the last address.
				 */
				continue;
			} else {
				int on = 1;
				/* optional: works better if dual-binding to wildcard
				 * address
				 */
				if (aip->ai_family == AF_INET6) {
					setsockopt(ctrlfd[nsock], IPPROTO_IPV6, IPV6_V6ONLY,
					(char *)&on, sizeof(on));
					/* errors are ignored */
				}

				if (setsockopt(ctrlfd[nsock], SOL_SOCKET, SO_REUSEADDR, (void *)&on,
					sizeof(on)) < 0) {
					syslog(LOG_ERR, "Error setsockopt. %m");
					close(ctrlfd[nsock]);
					continue;
				}

				/* set QoS socket options */
				qos_setup_socket(aip->ai_family,
						 ctrlfd[nsock],
						 qos_ctrl_dsfield,
						 qos_ctrl_dot1prio);

				if (bind(ctrlfd[nsock], aip->ai_addr,
					aip->ai_addrlen) < 0 ) {
					syslog(LOG_ERR, "Error bind. %m");
					close(ctrlfd[nsock]);
					continue;
				}
				if (listen(ctrlfd[nsock], 1) < 0) {
					syslog(LOG_ERR, "Error listen. %m");
					close(ctrlfd[nsock]);
					continue;
				}
			}
			nsock++;
		}
		freeaddrinfo(res);
		if (nsock == 0) {
			syslog(LOG_ERR, "Unable to get a TCP socket.");
			exit(EXIT_FAILURE);
		}
      
		/* check that we were able to obtain the sockets */
		for (;;) {
			int maxfd = 0;
			int err;

			FD_ZERO(&rfds);

			for (i = 0; i < nsock; i++) {
				FD_SET(ctrlfd[i], &rfds);
				maxfd = max(maxfd, ctrlfd[i]);
			}

			/* wait for any connection without timeout */
			do {
				err = select(maxfd + 1, &rfds, 0, 0, 0);
			} while(err == -1 && errno == EINTR);

			if (err == 0) {
				break;
			}

			for (i = 0; i < nsock; i++) {
				/* accept the incoming connection and fork  */
				if (FD_ISSET(ctrlfd[i], &rfds)) {
					int fd;
					remote_addrlen = sizeof(remote_addr);
					if ((fd = accept(ctrlfd[i],
							 (struct sockaddr *)&remote_addr,
							 &remote_addrlen)) < 0) {
						continue;
					} else {
						int pid;

						if ((max_connections) > 0 &&
						    (active_connections >= max_connections)) {
							DEBUG(fprintf(stderr, "Too many clients dropping the connection\n"));
							DO_RESP(fd, r_too_many_clients);
							close(fd);
							continue;
						}

						active_connections++;
						pid = fork();
						if (pid < 0) {
							syslog(LOG_ERR, "Failed to fork. %m");
						} else if (pid == 0) {
							/* in child */
							ftpd_main(fd, &remote_addr);
							/* Exit, this will cause a SIGCHLD to
							 * the parent and we return the fd as
							 * status code so it knows which.
							 */
							exit(fd);
						}
						/* in parent */
					}
				}
			}
		}
		for (i = 0; i < nsock; i++) {
			close(ctrlfd[i]);
		}
	}

	return 0;
}

/* return 0 if signal initialisation succeeds or -1 */
static int
signals_init(void)
{
	struct sigaction sa;

	sa.sa_flags = 0;
	if (sigemptyset(&sa.sa_mask) < 0) {
		syslog(LOG_ERR, "Error: sigemptyset %m");
		return -1;
	}
	if (sigaddset(&sa.sa_mask, SIGCHLD) < 0
	    || sigaddset(&sa.sa_mask, SIGPIPE) < 0
	    || sigaddset(&sa.sa_mask, SIGTERM) < 0
	    || sigaddset(&sa.sa_mask, SIGSEGV) < 0
	    || sigaddset(&sa.sa_mask, SIGBUS) < 0
	    || sigaddset(&sa.sa_mask, SIGINT) < 0) {
		syslog(LOG_ERR, "Error: sigaddset %m");
		return -1;
	}

	sa.sa_handler = sigchld;
	if (sigaction(SIGCHLD, &sa, NULL) < 0) {
		syslog(LOG_ERR, "Error: sigaction %m");
		return -1;
	}

	sa.sa_handler = sigterm;
	if (sigaction(SIGTERM, &sa, NULL) < 0) {
		syslog(LOG_ERR, "Error: sigaction %m");
		return -1;
	}

	sa.sa_handler = sigabort;
	if (sigaction(SIGSEGV, &sa, NULL) < 0
	    || sigaction(SIGBUS, &sa, NULL) < 0
	    || sigaction(SIGINT, &sa, NULL) < 0) {
		syslog(LOG_ERR, "Error: sigaction %m");
		return -1;
	}

	/* Ignore SIGPIPE so write to stopped client won't terminate us. */
	sa.sa_handler = SIG_IGN;
	if (sigaction(SIGPIPE, &sa, NULL) < 0) {
		syslog(LOG_ERR, "Error: sigaction %m");
		return -1;
	}

	return 0;
}

/* handle process termination, iterate and close file descriptors */
static void
sigchld(int dummy)
{
	int status;
	pid_t pid;

	while ((pid = waitpid(-1, &status, WNOHANG)) > 0) {
		DEBUG(fprintf(stderr, "reaping child %d: status %d\n",
			      pid, status));
		/* close the socket - the child returns the fd with exit()
		 * since we also got some normal exit(0)'s, and we probably
		 * don't want to close stdin, we check for fd == 0 as well.
		 */
		if (WIFEXITED(status) && WEXITSTATUS(status)) {
			close(WEXITSTATUS(status));
		}


		if (WIFSIGNALED(status)) {
			syslog(LOG_INFO, "Child died on signal: %d",
			       WTERMSIG(status));
		}
	}
	active_connections--;
}

/* abort on fatal error */
static void
sigabort(int signo)
{
	syslog(LOG_ERR, "Aborting on signal: %d", signo);
	abort();
}

/* may want to wait for transfers in progress */
static void
sigterm(int dummy)
{
	terminate = 1;
	syslog(LOG_INFO, "Exiting on signal %d", SIGTERM);
}

/* step beyond whitespace in the beginning of a string and return
   first non-whitespace character or \0 */
static char *
gobble_space(char *c)
{
	while (*c && isspace(*c))
		c++;
	return c;
}

/* return the address family based on the given argument
   return -1 if not supported */
static int ftp_to_inet_addr_family(int argument)
{
	switch (argument) {
	case ARG_AF_INET:
		return AF_INET;
	case ARG_AF_INET6:
		return AF_INET6;
	default:
		return -1;
	}
}

/* validate IP address and port */
static int
validate_ip_address(struct s_client *client)
{
	char *strpoi = NULL;
	char iface[IFNAMSIZ];

	/* Add any port check here */

	/* Check for valid IP address */
	if ((strpoi = strchr(client->ip, '%')) != NULL) {
		strpoi[0] = '\0';
	}
	switch (client->addr->ss_family) {
		case AF_INET:
		{
			struct in_addr s4;
			if (inet_pton(AF_INET, client->ip, &s4) > 0) {
				/* Add additional checks here */
				return 0;
			}
		}
		break;
		case AF_INET6:
		{
			struct in6_addr s6;
			if (inet_pton(AF_INET6, client->ip, &s6) > 0) {
				/* Add additional checks here */
				if (IN6_IS_ADDR_LINKLOCAL(&s6)) {
					int ifn = ((struct sockaddr_in6 *)client->addr)->sin6_scope_id;
					strcat(client->ip, "%");
					strcat(client->ip, if_indextoname(ifn, iface));
				}
				return 0;
			}
		}
		break;
		default:
		break;
	}
	return -1;
}

/* provide some basic help */
static void
do_help(int fd, char *args)
{
	if (!strlen(args)) {
		DO_RESP(fd, r_help);
	} else if (IS_CMD(args, c_site)) {
		DO_RESP(fd, r_sitehelp);
	} else {
		DO_RESP(fd, r_nohelp);
	}
}

/* change access permissions to what is hidden in args,
   e.g. site chmod 775 foo */
static void
do_site(int fd, char *args)
{
	if (IS_CMD(args, c_chmod)) {
		mode_t mode;
		char *filename;
		char buf[257];

		args += 5;
		mode = strtol(args, &args, 8);
		args = gobble_space(args);
		filename = args;

		if (getcwd(buf, 192) == NULL
		    || strlen(buf) + strlen(filename) + 1 > 256) {
			DO_RESP(fd, r_bad_file);
			return;
		}

		strcat(buf, "/");
		strcat(buf, filename);
		/* try to set mode for filename */
		if (chmod(filename, mode) < 0) {
			syslog(LOG_ERR, "Failed to chmod %s: %s", filename,
			       strerror(errno));
			send_error_resp(fd);
		} else {
			DO_RESP(fd, r_okay);
		}
	}
	else if (IS_CMD(args, c_reboot)) {
		if (system("/sbin/init 6") < 0) {
			syslog(LOG_ERR, "Failed to reboot: %m");
			send_error_resp(fd);
		} else {
			syslog(LOG_INFO, "Rebooting.");
			DO_RESP(fd, r_okay);
		}
	} else {
		DO_RESP(fd, r_notimpl);
	}
}

/* change current working directory to dirname without checking access
   permissions */
static void
do_chdir(int fd, const char *dirname)
{
	if (chdir(dirname) < 0) {
		send_error_resp(fd);
		return;
	}
	DO_RESP(fd, r_success);
}

/* handle a ftp session where the fd is the established socket
   identified by the remote_addr */
static void
ftpd_main(int fd, struct sockaddr_storage *remote_addr)
{
	uid_t uid;
	gid_t gid;
	char username[U_P_BUFLEN];
	char password[U_P_BUFLEN];
	int login;
	int state;
	struct s_client client;
	char command[MAX_CMD_SIZE + 1];
	char rnfrbuffer[MAX_CMD_SIZE + 1];
	char client_addr[INET6_ADDRSTRLEN];
	char client_service[NI_MAXSERV];
	int res;
#if A_ACCESS_LOG
	char line[32];
#endif

	/* start by not being authenticated */
	uid = -1;
	gid = -1;

	/* expect authentication in the initial state */
	state = FST_AUTHENTICATE1;

	/* for remembering the Rename-From name */
	rnfrbuffer[0] = 0;

	client.addr = remote_addr;
	client.fd = -1;
	client.block_non_epsv = 0;

	username[0] = 0;

	if ((res = getnameinfo((struct sockaddr *)client.addr, sizeof(struct sockaddr_storage),
			       client_addr, sizeof(client_addr),
			       client_service, sizeof(client_service),
			       NI_NUMERICHOST)) != 0) {
		client_addr[0] = '\0';
		client_service[0] = '\0';
		syslog(LOG_WARNING, "Failed to getnameinfo %s", gai_strerror(res));
	}

#if A_ACCESS_LOG
	axaccess(LOG_INFO,
		client_addr,
		"",
		PROT_STR,
		"Accepted request from client.");
#else
	syslog(LOG_INFO, "Accepted request from %s %s", client_addr, client_service);	
#endif

	DEBUG(fprintf(stderr, "request on fd %d\n", fd));

	/* default data format is binary */
	data_format = BINARY_MODE;

	/* read configurations  */
	set_virtual_targets();

	/* show the client what we are */
	DO_RESP(fd, set_banner());
	while (!terminate) {
		if (get_command(fd, command) < 0) {
			/* if an error occured while reading the next
			 * command, this session should be purged
			 */
			break;
		}

		/* check for QUIT in all states  */
		if (IS_CMD(command, c_quit)) {
			break;
		}

		/* allow HELP, SYST and NOOP in all states */
		if (IS_CMD(command, c_help)) {
			/* client asks for help */
			do_help(fd, gobble_space(command + 4));
			continue;
		}
		else if (IS_CMD(command, c_syst)) {
			/* client asks what kind of system we run on */
			DO_RESP(fd, r_system);
			continue;
		}
		else if (IS_CMD(command, c_noop)) {
			DO_RESP(fd, r_okay);
			continue;
		}

		/* state machine with three states: not authenticated,
		 * entered username, and entered password (running)
		 */
		switch (state) {
		case FST_AUTHENTICATE1:
			if (IS_CMD(command, c_user)
			    && HAS_PARAM(command, c_user)) {
				DEBUG(fprintf(stderr, "username %s\n", command + 5));
				/* copy and terminate user name */
				strncpy(username, command + 5, U_P_BUFLEN - 1);
				username[U_P_BUFLEN - 1] = 0;
				DO_RESP(fd, r_userok);
				state = FST_AUTHENTICATE2;
			}
			else {
				DO_RESP(fd, r_badseq);
			}
			break;

		case FST_AUTHENTICATE2:
			if (IS_CMD(command, c_pass)) {
				/* reject all except root when restricted */
				if (root_login_only > 0) {
					if (strcmp(username, ROOT_USER)) {
						DO_RESP(fd, r_badlogin);
						state = FST_AUTHENTICATE1;

						/* do not log the incorrect username.
						 * the user might have accidentally typed the password
						 * there instead.
						 */
#if A_ACCESS_LOG 
						axblogin(client_addr,
							 "",
							 PROT_STR,
							 "Failed login attempt. Access denied. User must be root.");
#else
						syslog(LOG_INFO, "User access denied. User must be root.");
#endif
						break;
					}
				}

				/* copy and terminate password */
				strncpy( password, command + 5, U_P_BUFLEN - 1);
				password[U_P_BUFLEN - 1] = 0;
				DEBUG(fprintf(stderr, "password %s\n", password));
				login = check_login(username, password, &uid, &gid);
				if (login < 0) {
					DO_RESP(fd, r_badlogin);
					state = FST_AUTHENTICATE1;
					/* do not log the incorrect username,
					 * the user might have accidentally typed the password
					 * there instead
					 */
#if A_ACCESS_LOG 
					axblogin(client_addr,
						 "",
						 PROT_STR,
						 "Failed login attempt. Incorrect username/password.");
#else
					syslog(LOG_INFO, "Incorrect username/password.");
#endif
				}
				else {
					struct passwd *pw;
					struct stat mystat;

					DO_RESP(fd, r_loggedin);

#if A_ACCESS_LOG 
					snprintf(line, sizeof line, "%s%d", PROT_STR, getpid());
					axlogin(client_addr,
						username,
						line,
						IPPORT_FTP,
						PROT_STR,
						"-",
						"Client logged in.");
#else
					syslog(LOG_INFO, "User %s logged in.", username);
#endif

					/* regenerate password for user flash in special
					 * case SNMP handling of
					 */
					if ((pw = getpwuid(uid))
					    && strcmp(pw->pw_name, FLASH_USER) == 0
					    && stat(PROGRAM_FLASH_PASSWD, &mystat) >= 0) {
						system(PROGRAM_FLASH_PASSWD FLASH_USER);
					}
					
					/* authentication OK - switch to the chosen uid/gid */
					setegid(gid);
					seteuid(uid);

					state = FST_RUNNING;
				}
			}
			else {
				state = FST_AUTHENTICATE1;
				DO_RESP(fd, r_badseq);
			}
			break;

		case FST_RUNNING:
			if (IS_CMD(command, c_port)
			    && HAS_PARAM(command, c_port)) {
				/* get client IP address and port number */
				handle_port_cmd(fd, command, &client);
			}
			else if (IS_CMD(command, c_pasv)) {
				/* enter passive mode */
				handle_pasv_cmd(fd, &client);
			}
			else if (IS_CMD(command, c_list)
				 || IS_CMD(command, c_nlst)) {
				/* LIST/NLST same now */
				int len = strlen(command);

				if (len > 5 && command[5] != '-') {
					/* NLST -CF from ncftp
					 * client specified a directory
					 */
					char *c = command;
					c += 5;
					len -= 5;
					while (len && isspace(*c))
						c++;
					if (len) {
						do_list(c, fd, &client, IS_CMD(command, c_nlst));
					}
				}
				else {
					/* no dir specified, use present directory */
					do_list(".", fd, &client, IS_CMD(command, c_nlst));
				}
			}
			else if (IS_CMD(command, c_retr)
				 && HAS_PARAM(command, c_retr)) {
				/* client wants to retrieve a file */
				do_retr(gobble_space(command + 5), fd, &client);
			}
			else if (IS_CMD(command, c_stor)
				 && HAS_PARAM(command, c_stor)) {
				/* client wants to store a file */
				do_stor(gobble_space(command + 5), fd, &client);
			}
			else if (IS_CMD(command, c_type)) {
				/* client wants to set binary I or ascii A mode */
				if (command[5] == ASCII_MODE
				    || command[5] == BINARY_MODE) {
					data_format = command[5];
					DO_RESP(fd, r_okay);
				}
				else {
					DO_RESP(fd, r_unknown_mode);
				}
			}
			else if (IS_CMD(command, c_mkd)
				 && HAS_PARAM(command, c_mkd)) {
				/* create directory */
				if (!mkdir(gobble_space(command + 4), 0755)) {
					DO_RESP(fd, r_success);
				}
				else {
					send_error_resp(fd);
				}
			}
			else if (IS_CMD(command, c_rmd)
				 && HAS_PARAM(command, c_rmd)) {
				/* remove directory */
				if (!rmdir(gobble_space(command + 4))) {
					DO_RESP(fd, r_success);
				}
				else {
					send_error_resp(fd);
				}
			}
			else if (IS_CMD(command, c_dele)
				 && HAS_PARAM(command, c_dele)) {
				/* remove file */
				if (!unlink(gobble_space(command + 5)))
					DO_RESP(fd, r_success);
				else
					send_error_resp(fd);
			}
			else if (IS_CMD(command, c_pwd)) {
				/* print working directory */
				char buf[200];
				char *wdir = getcwd(buf, 200);
				if (wdir) {
					if (write_to_fd(fd, "257 \"", 5)
					    || write_to_fd(fd, wdir, strlen(wdir))
					    || write_to_fd(fd, "\" is current directory.\r\n", 25)) {
						return;
					}
				}
				else {
					DO_RESP(fd, r_error);
				}
			}
			else if (IS_CMD(command, c_cwd)
				 && HAS_PARAM(command, c_cwd)) {
				/* change working directory */
				do_chdir(fd, gobble_space(command + 4));
			}
			else if (IS_CMD(command, c_site)
				 && HAS_PARAM(command, c_site)) {
				do_site(fd, gobble_space(command + 5));
			}
			else if (IS_CMD(command, c_cdup)) {
				/* change to parent directory */
				do_chdir(fd, "..");
			}
			else if (IS_CMD(command, c_rnfr)
				 && HAS_PARAM(command, c_rnfr)) {
				/* rename from: check existence of file,
				   but do nothing */
				strncpy(rnfrbuffer, gobble_space(command + 5), MAX_CMD_SIZE);
				rnfrbuffer[MAX_CMD_SIZE] = 0;
				if (access(rnfrbuffer, F_OK) == 0)
					DO_RESP(fd, r_fileexists);
				else
					send_error_resp(fd);
			}
			else if (IS_CMD(command, c_rnto)
				 && HAS_PARAM(command, c_rnto)) {
				/* Second part of a rename. Use stored RNFR
				   name and do the rename.  */
				if (rnfrbuffer[0]
				   && rename(rnfrbuffer, gobble_space(command + 5)) == 0)
					DO_RESP(fd, r_success);
				else
					send_error_resp(fd);
			}
			else if (IS_CMD(command, c_eprt)
				 && HAS_PARAM(command, c_eprt)) {
				/* get client address and port */
				handle_eprt_cmd(fd, command, &client);
			}
			else if (IS_CMD(command, c_epsv)) {
				/* open (extended) passive connection */
				handle_epsv_cmd(fd, command, &client);
			}
			else {
				DO_RESP(fd, r_error);
			}
			break;

		default:
			break;
		}
	}

	DO_RESP(fd, r_goodbye);

	close(fd);
#if A_ACCESS_LOG
	/* If authentication ok */
	if (state == FST_RUNNING) {
		axlogout(client_addr,
		 	username,
		 	line,
		 	PROT_STR,
		 	"Client disconnected.");
	} else {
		axaccess(LOG_INFO,
			 client_addr,
			 "",
			 PROT_STR,
			 "Client disconnected.");
	}
#else
	syslog(LOG_INFO, "Client %s disconnected.", client_addr);
#endif

}

/* return the default banner r_hello if the banner file does not exist */
char *
set_banner()
{
	FILE *f;
	char *newline;

	/* read banner if the file exists or use a default banner  */
	if ((f = fopen(BANNER_FILE, "r"))) {
		strcpy(banner, "220 ");
		/* Room for "220 "+ "\r\n\0" */
		fgets(banner + 4, BANNER_LEN-7, f);
		fclose(f);
		/* banner which is a one-liner must end with \r\n */
		newline = strchr(banner, '\n');
		if (newline == NULL) {
			DEBUG(fprintf(stderr, "set_banner: adding CRLF\n"));
			newline = banner + strlen(banner);
			newline[0]='\r';
			newline[1]='\n';
			newline[2]='\0';
		} else if (newline && *(newline-1) != '\r') {
			DEBUG(fprintf(stderr, "set_banner: adding CR\n"));
			newline[0]='\r';
			newline[1]='\n';
			newline[2]='\0';
		}
	} else {
		strcpy(banner, r_hello);
	}

	return &banner[0];
}

/* read a command from the client until it ends with a newline
 * if an error occurs, return -1 */
static int
get_command(int fd, char *buf)
{
	int len = 0;

	while (len < MAX_CMD_SIZE && (!len || buf[len-1] != '\n')) {
		int r;
		fd_set rset;
		struct timeval tv;

		FD_ZERO(&rset);
		FD_SET(fd, &rset);

		/* Only wait up to FTPD_TIMEOUT seconds for a command */
		tv.tv_sec = FTPD_TIMEOUT;
		tv.tv_usec = 0;

		if ((r = select(fd + 1, &rset, NULL, NULL, &tv)) <= 0) {
			/* select returned error or a timeout occured
			 * in either case, we count it as an error.
			 */
			if (!r)
				syslog(LOG_INFO, "Control-connection timed out.");
			return -1;
		}
		r = read(fd, buf + len, MAX_CMD_SIZE - len);
		if (r < 0) {
			if (errno != EAGAIN && errno != EINTR)
				return -1;
		} else if (r == 0) {
			return -1;
		} else
			len += r;
	}
	if (buf[len-2] == '\r')
		len--;
	buf[len-1] = 0;
	DEBUG(fprintf(stderr, "command: %s\n", buf));
	return 0;
}

/* check if login is correct; if so return 0, uid and gid.
   on failure return -1 */
static int
check_login(char* user, char* pass, uid_t *uid, gid_t *gid)
{
	struct passwd *pw = getpwnam(user);
	char *password = NULL;

	if (pw == NULL) {
		DEBUG(fprintf(stderr, "getpwnam: (%s) %s\n", user, 
			      strerror(errno)));
		return -1;
	}

#if SHADOW_PASSWD_SUPPORT
	if (!geteuid())
	{
		struct spwd *spwd = getspnam(user);

		if (spwd) {
			password = spwd->sp_pwdp;
		}
	}
#endif

	if (!password) {
		password = pw->pw_passwd;
	}

	/* Check against the encrypted password. */
	if (!strcmp(crypt(pass, password), password)) {
		*uid = pw->pw_uid;
		*gid = pw->pw_gid;
		return 0;
	}

	return -1;
}

/* send an error response to the client on an open control
   connection */
static void
send_error_resp(int fd)
{
	switch (errno) {
	case EACCES:
		DO_RESP(fd, r_noaccess);
		break;
	case ENOENT:
		DO_RESP(fd, r_nosuchfile);
		break;
	case ENOTDIR:
		DO_RESP(fd, r_notadir);
		break;
	case ENOMEM:
		DO_RESP(fd, r_outofmem);
		break;
	case ENOSPC:
		DO_RESP(fd, r_outofspace);
		break;
	default:
		DO_RESP(fd, r_unknownerror);
		break;
	}
}

/* list files in directory dir based on the content in simple */
static void
do_list(const char *dir, int fd, struct s_client *client, int simple)
{
	int dfd;
	DIR *dirp;
	struct dirent *dp;

	dirp = opendir(dir);
	if (!dirp) {
		send_error_resp(fd);
		return;
	}

	DO_RESP(fd, r_openingdata);

	dfd = open_data_connection(client);

	if (dfd < 0) {
		DO_RESP(fd, r_cantopen);
	} else {
		if (!simple) {
			ls(dir, dirp, dfd);
		} else {
			/* very simple ls, just lists the names. */
			while ((dp = readdir(dirp)) != NULL) {
				write(dfd, dp->d_name, strlen(dp->d_name));
				write(dfd, "\r\n", 2);
			}
		}
		closedir(dirp);
		DO_RESP(fd, r_trcomplete);
		close(dfd);
	}
}

/* validate the client IP address and store it with the client port in
   struct s_client from the string command. Respond with okay or
   unknown error to the client */
static void
handle_port_cmd(int fd, const char *command, struct s_client *client)
{
	int a1, a2, a3, a4;
	int p1, p2;

	if (client->block_non_epsv){
		DO_RESP(fd, r_notperm);
		return;
	}

	if (sscanf(command, "PORT %d,%d,%d,%d,%d,%d",
		   &a1, &a2, &a3, &a4, &p1, &p2) == 6 &&
		   a1 < 256 && a2 < 256 && a3 < 256 && a4 < 256 &&
		   p1 < 256 && p2 < 256) {
		sprintf(client->ip,"%d.%d.%d.%d", a1, a2, a3, a4);
		client->port = ((p1 << 8) + p2);
		if (validate_ip_address(client) == 0) {
			if (client->fd >= 0) {
				close(client->fd);
				client->fd = -1;
			}
			DO_RESP(fd, r_okay);
			return;
		}
	}

	DO_RESP(fd, r_unknownerror);
}

/* Validate the client IPv4 or IPv6 address and store it with the
 * client port in struct s_client from the string command. Respond
 * with okay, network protocol not supported or unknown error to the
 * client.
 *
 * EPRT<space><d><net-prt><d><net-addr><d><tcp-port><d>
 * <d> is a delimiter character
 * <net-port> is address family
 * <net-addr> is address
 * <tcp-port> is port
 */
static void handle_eprt_cmd(int fd, char *command, struct s_client *client)
{
	int af;
	int tcp_port;
	char delim;
	char *next;
	char *end;

	if (client->block_non_epsv){
		DO_RESP(fd, r_notperm);
		return;
	}

	if (strncmp(command, "EPRT ", strlen("EPRT ")) != 0) {
		goto bail;
	}
	next = command + strlen("EPRT ");
	delim = *next++;
	if ((delim < 33) || (delim > 126)) {
		goto bail;
	}
	/* Check AF. */
	end = strchr(next, delim);
	if (NULL == end) {
		goto bail;
	}
	*end = '\0';
	af = atoi(next);
	next = end + 1;

	/* Get address */
	end = strchr(next, delim);
	if (NULL == end) {
		goto bail;
	}
	*end = '\0';

	if (ftp_to_inet_addr_family(af) == -1) {
		syslog(LOG_INFO, "EPRT unknown address family %d.", af);
		DO_RESP(fd, r_protonotsupp);
		return;
	}
	
	/* Save IP address */
	strcpy(client->ip, next);
	next = end + 1;

	/* Get TCP port */
	end = strchr(next, delim);
	if (NULL == end) {
		goto bail;
	}
	*end = '\0';
	tcp_port = atoi(next);
	/* FIXME Filter bad ports? (control port, port < 1024) */
	client->port = tcp_port;
	if (validate_ip_address(client) == 0) {
		if (client->fd >= 0) {
			close(client->fd);
			client->fd = -1;
		}
		DO_RESP(fd, r_okay);
		return;
	}
  bail:
	DO_RESP(fd, r_unknownerror);
}

/* opens a passive data connection. Respond with entering passive mode,
   network protocol not supported, syntax error or unknown error. */
static void handle_epsv_cmd(int fd, char *command, struct s_client *client)
{
	int client_fd;
	int requested_af = 0;
	int all_command = 0;
	int af = AF_INET;

	/* EPSV has an optional argument being either an AF specifier,
	 * or ALL with special meaning that all succeeding data
	 * connection setup commands (EPRT, PORT, PASV, EPSV, etc.) must
	 * be ignored.
	 */
	if (HAS_PARAM(command, c_epsv)) {
		char *arg = command + strlen(c_epsv);

		if (*arg++ != ' '){
			DO_RESP(fd, r_error);
			return;
		}
		if (0 == strcmp(arg, "ALL")) {
			all_command = 1;
			client->block_non_epsv = 1;
			DO_RESP(fd, r_okay);
			return;
		}
		requested_af = atoi(arg);
		af = ftp_to_inet_addr_family(requested_af);
		if (af == -1) {
			syslog(LOG_INFO, "EPSV unknown address family %d.", requested_af);
			DO_RESP(fd, r_protonotsupp);
			return;
		}
	} else {
		af = client->addr->ss_family;
		/* When issued without argument, choose the network protocol
		 * based on the protocol used for the control connection.
		 * (RFC2428)
		 */
	}
	/* open_passive_data_connection() will open a listen socket that works
	 * for both AF_INET and AF_INET6.  If more protocols are supported this
	 * code will need fixing.
	 */
	if ((client_fd = open_passive_data_connection(af)) >= 0) {
		struct sockaddr_storage addr;
		socklen_t addr_len = sizeof addr;
		int port = 0;

		DEBUG(fprintf(stderr, "EPSV: opened data connection\n"));
		if (getsockname(client_fd, (struct sockaddr*)&addr, &addr_len) >= 0) {
			if (addr.ss_family == AF_INET) {
				port = ntohs(((struct sockaddr_in*)&addr)->sin_port);
				DEBUG(fprintf(stderr, "EPSV: AF_INET, port %d\n", port));
			} else if (addr.ss_family == AF_INET6) {
				port = ntohs(((const struct sockaddr_in6*)&addr)->sin6_port);
				DEBUG(fprintf(stderr, "EPSV: AF_INET6, port %d\n", port));
			}
		}

		if (port) {
			char buffer[80];

			if (client->fd >= 0) {
				close(client->fd);
			}
			client->fd = client_fd;
			snprintf(buffer, 80,
				 "229 Entering Extended Passive Mode (|||%d|)\r\n",
				 port);
			DO_RESP(fd, buffer);
			return;
		}
		close(client_fd);
	}

	DO_RESP(fd, r_unknownerror);
}

/* opens a passive data connection on file descriptor fd
   and listens, returns the file descriptor or -1 on fatal error. */
static int
open_passive_data_connection(int af)
{
	int fd;

	fd = socket(af, SOCK_STREAM, 0);
	if (fd < 0) {
		syslog(LOG_ERR, "Unable to get a TCP socket.");
		return -1;
	}

	/* set QoS socket options */
	qos_setup_socket(af, fd, qos_data_dsfield, qos_data_dot1prio);

	if (listen(fd, 1) < 0) {
		syslog(LOG_ERR, "Failed to get socket to listen to port (- listen() failed). %m");
		close(fd);
		return -1;
	}

	return fd;
}

/* open a data connection to the client and return the file
   descriptor fd or -1 on fatal error */
static int
open_data_connection(struct s_client *client)
{
	struct sockaddr_storage addr;
	int addr_len;
	int err;
	int tries = 1;
	int on = 1;
	int fd = -1;
	struct addrinfo hints;
	struct addrinfo *res;
	char port_str[32];
	

	
	if (client->fd != -1) {
		/* passive mode entered */

		if ((fd = accept(client->fd, NULL, 0)) < 0) {
			syslog(LOG_ERR, "Failed to accept connection: %m");
		}

		close(client->fd);
		client->fd = -1;

		return fd;
	}

	/* active open of data connection */
	fd = socket(client->addr->ss_family, SOCK_STREAM, 0);
	if (fd < 0) {
		syslog(LOG_ERR, "Unable to get a TCP socket: %m");
		goto bad;
	}

	if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof on) < 0) {
		syslog(LOG_ERR, "Failed to enable socket option "
				"SO_REUSEADDR: %m");
		goto bad;
	}

	/* set QoS socket options */
	qos_setup_socket(client->addr->ss_family,
			 fd, qos_data_dsfield, qos_data_dot1prio);

	sprintf(port_str, "%d", (ctrl_port - 1));
	memset(&hints, 0, sizeof(hints));
	hints.ai_family = client->addr->ss_family;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags = AI_PASSIVE;

	if ((err = getaddrinfo(NULL, port_str, &hints, &res)) != 0 ||
	     sizeof(addr) < res->ai_addrlen) {
		syslog(LOG_ERR, "Failed to getaddrinfo %s", gai_strerror(err));
		goto bad;
	}

	addr_len = res->ai_addrlen;
	memcpy(&addr, res->ai_addr, addr_len);
	freeaddrinfo(res);

	
	for (;; tries++) {
		if (bind(fd, (struct sockaddr *)&addr, addr_len) >= 0)
			break;
		if (errno != EADDRINUSE || tries > 10) {
			syslog(LOG_ERR, "Unable to bind data socket to port "
					"%d: %m", ctrl_port - 1);
			goto bad;
		}
		sleep(tries);
	}

	sprintf(port_str, "%d", client->port);
	memset(&hints, 0, sizeof(hints));
	hints.ai_family = client->addr->ss_family;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags = AI_NUMERICHOST;

	if ((err = getaddrinfo(client->ip, port_str, &hints, &res)) != 0 ||
	     sizeof(addr) < res->ai_addrlen) {
		syslog(LOG_ERR, "Failed to getaddrinfo %s", gai_strerror(err));
		goto bad;
	}

	addr_len = res->ai_addrlen;
	memcpy(&addr, res->ai_addr, addr_len);
	freeaddrinfo(res);

	if (connect(fd, (struct sockaddr *)&addr,  addr_len) < 0) {
		syslog(LOG_ERR, "Failed to connect data socket: %m");
		goto bad;
	}

	DEBUG(fprintf(stderr, "data connection to %s, port %d\n",
		      client->ip, client->port));
	return fd;

bad:
	on = errno;                 /* Save errno for return */
	if (fd != -1) {
		close(fd);
	}
	errno = on;
	return -1;
}

/* write to control connection fd when the command buf of length len
   is not a trivial command listed */
int
write_to_fd(int fd, const char *buf, int len)
{
		int w;

	while (len) {
		if ((w = write(fd, buf, len)) < 0) {
			if (errno != EINTR && errno != EAGAIN)
				return w;
		} else {
			len -= w;
			buf += w;
		}
	}
	return 0;
}

/* opens a passive data connection and FIXME ignores the return value,
   closes the previously opened client connection and replaces it with
   the passive one. Respond with entering passive mode or unknown error. */
static void
handle_pasv_cmd(int fd, struct s_client *client)
{
	int client_fd;

	if (client->block_non_epsv){
		DO_RESP(fd, r_notperm);
		return;
	}

	if ((client_fd = open_passive_data_connection(AF_INET)) >= 0) {
		struct sockaddr_storage addr;
		socklen_t addr_len = sizeof addr;
		unsigned int ip = 0;
		int port = 0;

		if (getsockname(fd, (struct sockaddr*)&addr, &addr_len) >= 0) {
			if (addr.ss_family == AF_INET) {
				ip = ntohl(((struct sockaddr_in*)&addr)->sin_addr.s_addr);
			} else if ((addr.ss_family == AF_INET6) &&
				    IN6_IS_ADDR_V4MAPPED(&((struct sockaddr_in6*)&addr)->sin6_addr)) {
				ip = ntohl(((struct sockaddr_in6*)&addr)->sin6_addr.s6_addr32[3]);
			}
		}

		if (getsockname(client_fd, (struct sockaddr*)&addr, &addr_len) >= 0) {
			if (addr.ss_family == AF_INET) {
				port = ntohs(((struct sockaddr_in*)&addr)->sin_port);
			} else if ((addr.ss_family == AF_INET6) &&
				    IN6_IS_ADDR_V4MAPPED((const struct sockaddr_in6*)&addr)) {
				port = ntohs(((const struct sockaddr_in6*)&addr)->sin6_port);
			}
		}

		if (ip && port) {
			char buffer[80];

			if (client->fd >= 0) {
				close(client->fd);
			}
			client->fd = client_fd;
			
			sprintf(buffer,
				"227 Entering Passive Mode (%d,%d,%d,%d,%d,%d)\r\n",
				ip >> 24, (ip >> 16) & 0xFF,
				(ip >> 8) & 0xFF, ip & 0xFF,
				port >> 8, port & 0xFF);
			DO_RESP(fd, buffer);
			return;
		}
		close(client_fd);
	}

	DO_RESP(fd, r_unknownerror);
}

/* open fname as a virtual or regular file and send local file content
   to the client in binary or ASCII format. Response codes are sent
   and it returns or exits on fatal errors */
static void
do_retr(char *fname, int fd, struct s_client *client)
{
	int dfd; /* remote data connection */
	int ffd; /* local target file descriptor */
	int virtual_type; /* type of virtual target */
	int statfd; /* read from stdout in child */
	struct stat mystat;

	/* first assume it may be opened as a virtual target, secondly
	   as a regular file and send an error response if neither is true */
	ffd = open_virtual(fname, O_RDONLY, &virtual_type, NULL, &statfd);
	if (ffd == 0) {
		/* not a virtual target */
		/*  stat the requested local file or send an error response */
		if (stat(fname, &mystat) < 0) {
			send_error_resp(fd);
			return;
		}
		/* fetch directory is not supported, send an error response */
		if (S_ISDIR(mystat.st_mode)) {
			DO_RESP(fd, r_bad_file);
			return;
		}
		/* file accessible or send an error response */
		if (access(fname, R_OK) < 0) {
			send_error_resp(fd);
			return;
		}
		ffd = open(fname, O_RDONLY);
	}
	if (ffd < 0) {
		send_error_resp(fd);
		return;
	}

	/* open the remote data connection in either active or passive mode
	   or send an error response */
	DO_RESP(fd, r_openingdata);
	dfd = open_data_connection(client);
	if (dfd < 0) {
		DO_RESP(fd, r_cantopen);
		return;
	}

	if (data_format == BINARY_MODE) {
		char *buf;
		int r,w, rtot=0;

		buf = (char *)malloc(FILEBUFSIZE);
		if (!buf) {
			syslog(LOG_ERR, "Memory allocation failed. %m");
			send_error_resp(fd);
			return;
		}
		syslog(LOG_DEBUG, "send %s in binary mode", fname);
		errno = 0;
		while (((r = read(ffd, buf, FILEBUFSIZE)) > 0)
		       || (r < 0
			   && (errno == EINTR || errno == EAGAIN))) {
			if (r > 0){
				rtot += r;
				if ((w = write_to_fd(dfd, buf, r)) < 0) {
					syslog(LOG_DEBUG, "r %i != w %i, "
					       "rtot=%i errno=%i",
					       r, w,rtot, errno);
					break;
				}
			}
		}
		close(ffd);
		close(dfd);
		free(buf);
		DO_RESP(fd, r_trcomplete);
	} else if (data_format == ASCII_MODE) {
		FILE *filestream = fdopen(ffd, "r");
		char *buf;
		char *ok;

		buf = (char *)malloc(FILEBUFSIZE);
		if (!buf) {
			syslog(LOG_ERR, "Memory allocation failed. %m");
			send_error_resp(fd);
			return;
		}
		syslog(LOG_DEBUG, "send %s in ascii mode", fname);

		/* read line-by-line, checking for LF, allow other errors
		   than EOF, e.g. EINTR */
		clearerr(filestream);
		while ((ok = fgets(buf, FILEBUFSIZE - 1, filestream))
		       || (!feof(filestream))) {

			if (ferror(filestream)){
				syslog(LOG_INFO, "feof(): %i ferror():%i errno=%i '%s'", 
				       feof(filestream), ferror(filestream), errno, buf);
			}
			if (!feof(filestream)){
				int len = strlen(buf);

				/* insert CRLF, but only if the LF was not
				   already preceded by a CR */
				if (len && buf[len - 1] == '\n'
				    && (len < 2 || buf[len - 2] != '\r')) {
					strcpy(buf + len - 1, "\r\n");
					len++;
				}
				write_to_fd(dfd, buf, len);
			}
			*buf = '\0';
		}
		fclose(filestream); /* closes ffd as well */
		close(dfd);
		free(buf);
		DO_RESP(fd, r_trcomplete);
	} else {
		syslog(LOG_ERR, "Unknown transfer mode.");
	}
}

/* open fname as a virtual or regular file and receive local file content
   from the client in binary or ASCII format. Response codes are sent
   and it returns or exits on fatal errors */
static void
do_stor(char *fname, int fd, struct s_client *client)
{
	int ffd; /* local target file descriptor */
	int virtual_type; /* type of virtual target */
	int statfd1; /* read from stdout in child before opening data conn. */
	int statfd2; /* read from stdout in child after opening data conn. */
	int dfd; /* remote data connection */
	struct stat mystat;
	mode_t modes = DEFAULT_MODE_REGULAR_FILES;
	int r;
	int q;
	char *p = NULL;
	char *buf = NULL;

	/* first assume it may be opened as a virtual file, secondly
	   as a regular file and send an error response if neither is true */
	ffd = open_virtual(fname, O_WRONLY, &virtual_type, &statfd1, &statfd2);
	if (ffd == 0) {
		/* not a virtual target */
		/* get stats on the requested local file if it exists */
		if (stat(fname, &mystat) == 0) {
			/* exists */
			modes = mystat.st_mode & 0777;

			/* store directory is not supported, send an
			   error response */
			if (S_ISDIR(mystat.st_mode)) {
				DO_RESP(fd, r_bad_file);
				return;
			}

			/* if the file cannot be accessed, send an
			   error response */
			if (access(fname, W_OK) < 0) {
				send_error_resp(fd);
				return;
			}
		}
		ffd = open(fname, O_WRONLY | O_CREAT | O_TRUNC, modes);
	}
	if (ffd <= 0) {
		send_error_resp(fd);
		return;
	}

	/*
	 * The virtual target is duplex, forward all messages. Since opening
	 * the data connection will delay status messages (at least in some
	 * clients) we must forward statfd1-messages now, and statfd2-messages
	 * later.
	 */
	if (virtual_type == VIRT_CGI) {
		char line[81];
		int n;

		DO_RESP(fd, r_shutdown);
		while ((n = read(statfd1, line, sizeof line)) > 0) {
			if (write_to_fd(fd, line, n) < 0) {
				send_error_resp(fd);
				return;
			}
		}
	}

	/* need a buffer for the data connection */
	if ((buf = (char *)malloc(FILEBUFSIZE)) == NULL) {
		syslog(LOG_ERR, "Memory allocation failed. %m");
		send_error_resp(fd);
		close(ffd);
		return;
	}
	/* open the remote data connection in either active or passive mode
	   or send an error response */
	DO_RESP(fd, r_openingdata);
	dfd = open_data_connection(client);
	if (dfd < 0) {
		DO_RESP(fd, r_cantopen);
		return;
	}

	q = 0;
	if (data_format == BINARY_MODE) {
		syslog(LOG_DEBUG, "receive %s in binary mode", fname);
		errno = 0;
		while (!q
		       && ((r = read(dfd, buf, FILEBUFSIZE)) > 0
			   || (r < 0
			       && (errno == EINTR || errno == EAGAIN)))) {
			p = buf;
			while (r > 0) {
				int w = write(ffd, p, r);
				DEBUG(syslog(LOG_DEBUG,
					     "write returned: %i", w));
				if (w < 0) {
					if (errno != EINTR
					    && errno != EAGAIN) {
						q++;
						break;
					}
				} else {
					r -= w;
					p += w;
				}
			}
		}
		if (q && errno == ENOSPC) {
			/* No space left on device.  */

			/* Since the whole file wasn't uploaded in its
			 * entirety, we could just as well truncate it
			 * in order to save space on the device.
			 */
			DO_RESP(fd, r_outofspace);
			if (ftruncate(ffd, 0) < 0) {
				syslog(LOG_ERR, "failed to truncate file %s "
						"(errno = %d). %m",
				       fname, errno);
			}
		}
		close(dfd);
		close(ffd);
		free(buf);
	} else if (data_format == ASCII_MODE) {
		FILE *filestream;
		FILE *ofilestream;

		syslog(LOG_DEBUG, "receiving %s in ascii mode", fname);

		filestream = fdopen(dfd, "r");
		ofilestream = fdopen(ffd, "w");

		/* FIXME if a line is FILEBUFSIZE long
		 * FIXME the last '\n' will not be in the buffer and the \r
		 * FIXME will not be removed. However it will work almost
		 * FIXME _all_ of the time ;-).
		 */

		while (!q && fgets(buf, FILEBUFSIZE - 1, filestream)) {
			p = buf;
			r = strlen (p);
			if ((r >= 2)
			    && (p[r - 2] == '\r') && (p[r - 1] == '\n')) {
				p[r - 2] = '\n';
				p[r - 1] = '\0';
				r--;
			}
			if (fputs(p, ofilestream) == EOF) {
				q++;
			}
		}

		if (q) {
			/* No space left on device.  */
			DO_RESP(fd, r_outofspace);
			/* Since the whole file wasn't uploaded in its
			 * entirety, we could just as well truncate it
			 * in order to save space on the device.
			 */
			if (ftruncate(ffd, 0) < 0) {
				syslog(LOG_ERR, "failed to truncate "
				       "file %s (errno = %d). %m",
				       fname, errno);
			}
		}
		fclose(filestream);
		fclose(ofilestream);
		free(buf);
	} else {
		syslog(LOG_ERR, "Unknown transfer mode.");
		return;
	}

	/* the virtual target is duplex, forward statfd2-messages */
	if (virtual_type == VIRT_CGI) {
		char line[81];
		int n;

		DO_RESP(fd, r_virtexec);
		while ((n = read(statfd2, line, sizeof line)) > 0) {
			/*
			 * Ignore errors since we have started executing
			 * virtual target.
			 */
			write_to_fd(fd, line, n);
		}
		DO_RESP(fd, r_virtexit);
	} else {
		DO_RESP(fd, r_trcomplete);
	}
}

/* set QoS socket options  */
static void 
qos_setup_socket(int af, int sock, int dsfield, int prio)
{
	int tos;
	/*
	 * ds-field is 6bits
	 */
	dsfield &= 0x3f;
	tos = dsfield << 2;
  
	switch (af) {
	case AF_INET:
		setsockopt(sock, SOL_IP, IP_TOS, &tos, sizeof(tos));
		break;
	case AF_INET6:
#ifdef IPV6_TCLASS		
		setsockopt(sock, SOL_IPV6, IPV6_TCLASS, &tos, sizeof(tos));
#endif		
		break;
	default:
		syslog(LOG_ERR, "%s: unsupported AF", __func__);
		break;
	}

	if (setsockopt(sock, SOL_SOCKET, SO_PRIORITY, &prio, sizeof(prio)) < 0)	 {
		syslog(LOG_ERR, "Error setsockopt. %m");
		exit(1);
	}
}

