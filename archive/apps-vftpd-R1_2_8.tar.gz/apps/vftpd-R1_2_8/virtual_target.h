#ifndef __VIRTUAL_TARGET_H__
#define __VIRTUAL_TARGET_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <grp.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>

#include "fdipc.h" /* get_send_socket and write_fd */

/* defined virtual targets */
#define VTARGET_FILE "/etc/vftpd.conf"
#define TRANSFER_TOKEN "Transfer"
#define CGI_TOKEN "Cgi"

/* longest possible path with or without parameters */
#define MAX_CMD_LENGTH 1024
#define MAX_PATH_LENGTH 250
#define MAX_NAME_LENGTH 100

/* transfer type, not virtual (0) or vitual duplex type (1) or virtual cgi (2) */
enum {
	NO_VIRT = 0,
	VIRT_TRANSFER = 1,
	VIRT_CGI = 2
};

struct virtual_target {
	struct virtual_target *next;
	int type;        /* transfer, cgi or duplex type */
	char *virtual;   /* virtual absolute path */
	char *real;      /* absolute path to cgi or to unix domain socket */
	int transfer_fd; /* socket to the daemon to recieve transfers */
};

extern void set_virtual_targets(void);
extern int open_virtual(char *name, const int amode, int *virtual_type,
			int *statfd1, int *statfd2);

#endif /* __VIRTUAL_TARGET_H__ */
