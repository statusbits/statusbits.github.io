#ifndef __LS_H__
#define __LS_H__

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <pwd.h>
#include <grp.h>
#include <time.h>
#include <unistd.h>
#include <string.h>

#ifdef	S_ISLNK
#define	LSTAT	lstat
#else
#define	LSTAT	stat
#endif

#define PATHLEN 512

/* external list command returns 0 or -1 on error */
extern int ls(const char *dirname, DIR *dirp, int fd);

#endif /* __LS_H__ */
