/* simple "ls -l" functionality. parts borrowed from here and there. */

#include "ls.h"

extern int write_to_fd(int fd, const char *buf, int len);

static int lsfile(const char *fullname, const char *name,
		  struct stat *statbuf, int fd);

static char *
modestring(int mode)
{
	static  char    buf[12];

	strcpy(buf, "----------");

	/*
	 * Fill in the file type.
	 */
	if (S_ISDIR(mode))
		buf[0] = 'd';
	if (S_ISCHR(mode))
		buf[0] = 'c';
	if (S_ISBLK(mode))
		buf[0] = 'b';
	if (S_ISFIFO(mode))
		buf[0] = 'p';
#ifdef  S_ISLNK
	if (S_ISLNK(mode))
		buf[0] = 'l';
#endif
#ifdef  S_ISSOCK
	if (S_ISSOCK(mode))
		buf[0] = 's';
#endif

	/*
	 * Now fill in the normal file permissions.
	 */
	if (mode & S_IRUSR)
		buf[1] = 'r';
	if (mode & S_IWUSR)
		buf[2] = 'w';
	if (mode & S_IXUSR)
		buf[3] = 'x';
	if (mode & S_IRGRP)
		buf[4] = 'r';
	if (mode & S_IWGRP)
		buf[5] = 'w';
	if (mode & S_IXGRP)
		buf[6] = 'x';
	if (mode & S_IROTH)
		buf[7] = 'r';
	if (mode & S_IWOTH)
		buf[8] = 'w';
	if (mode & S_IXOTH)
		buf[9] = 'x';

	/*
	 * Finally fill in magic stuff like suid and sticky text.
	 */
	if (mode & S_ISUID)
		buf[3] = ((mode & S_IXUSR) ? 's' : 'S');
	if (mode & S_ISGID)
		buf[6] = ((mode & S_IXGRP) ? 's' : 'S');
	if (mode & S_ISVTX)
		buf[9] = ((mode & S_IXOTH) ? 't' : 'T');

	return buf;
}

int
ls(const char *dirname, DIR *dirp, int fd)
{
	int		endslash;
	struct	dirent	*dp;
	char            fullname[PATHLEN];
	struct	stat	statbuf;

	endslash = (*dirname && (dirname[strlen(dirname) - 1] == '/'));
	
	while ((dp = readdir(dirp)) != NULL) {
		fullname[0] = '\0';
		
		if ((*dirname != '.') || (dirname[1] != '\0')) {
			strncpy(fullname, dirname, PATHLEN - 1);
			fullname[PATHLEN - 1] = 0;
			if (!endslash)
				strcat(fullname, "/");
		}
		
		strcat(fullname, dp->d_name);

		if (LSTAT(fullname, &statbuf) < 0) {
			perror(fullname);
			return -1;
		}

		if(lsfile(fullname, dp->d_name, &statbuf, fd) < 0) {
			return -1;
		}
	}	
	return 0;
}

/*
 * Get the time to be used for a file.
 * This is down to the minute for new files, but only the date for old files.
 * The string is returned from a static buffer, and so is overwritten for
 * each call.
 */

static char *
timestring(long t)
{
	long            now;
	char            *str;
	static  char    buf[26];

	time(&now);

	str = ctime(&t);

	strcpy(buf, &str[4]);
	buf[12] = '\0';

	if (buf[4] == '0')
		buf[4] = ' ';

	if ((t > now) || (t < now - 365*24*60*60L)) {
		buf[7] = ' ';
		strncpy(&buf[8], &str[20], 4);
	}

	return buf;
}

static int
lsfile(const char *fullname, const char *name, struct stat *statbuf, int fd)
{
	char		*cp;
	struct	passwd	*pwd;
	struct	group	*grp;
	static  char     buf[PATHLEN];
	static	char	username[12];
	static	int	userid;
	static	int	useridknown = 0;
	static	char	groupname[12];
	static	int	groupid;
	static	int	groupidknown = 0;

	memset(buf,0,PATHLEN);
	cp = buf;
	*cp = '\0';

	strcpy(cp, modestring(statbuf->st_mode));
	cp += strlen(cp);

	sprintf(cp, " %3d ", statbuf->st_nlink);
	cp += strlen(cp);

	/* optimize a bit and cache 1 lookup */

	if (!useridknown || (statbuf->st_uid != userid)) {
		pwd = getpwuid(statbuf->st_uid);
		if (pwd)
			strcpy(username, pwd->pw_name);
		else
			sprintf(username, "%d", statbuf->st_uid);
		userid = statbuf->st_uid;
		useridknown++;
	}

	sprintf(cp, "%-8s ", username);
	cp += strlen(cp);

	if (!groupidknown || (statbuf->st_gid != groupid)) {
		grp = getgrgid(statbuf->st_gid);
		if (grp)
			strcpy(groupname, grp->gr_name);
		else
			sprintf(groupname, "%d", statbuf->st_gid);
		groupid = statbuf->st_gid;
		groupidknown++;
	}

	sprintf(cp, "%-8s ", groupname);
	cp += strlen(cp);

	if (S_ISBLK(statbuf->st_mode) || S_ISCHR(statbuf->st_mode))
		sprintf(cp, "%3d, %3d ", (int)(statbuf->st_rdev >> 8),
			(int)(statbuf->st_rdev & 0xff));
	else
		sprintf(cp, "%8d ", (int)statbuf->st_size);
	cp += strlen(cp);
	
	sprintf(cp, "%-12s ", timestring(statbuf->st_mtime));

	if(write_to_fd(fd, buf, strlen(buf)) < 0)
		return -1;
	if(write_to_fd(fd, name, strlen(name)) < 0)
		return -1;
	
#ifdef	S_ISLNK
	if (S_ISLNK(statbuf->st_mode)) {
		int len;
		char linkname[PATHLEN];
		
		memset(linkname,0,PATHLEN);

		if(write_to_fd(fd, " -> ", 4) < 0)
			return -1;

		len = readlink(fullname, linkname, PATHLEN);

		if (len >= 0) {
			struct	stat	statlinkbuf;

			if(write_to_fd(fd, linkname, len) < 0)
				return -1;

			if (!(LSTAT(linkname, &statlinkbuf) < 0)) {
				if (S_ISDIR(statlinkbuf.st_mode)) {			
					/* add slash only if it's missing */
					if (linkname[len-1] != '/') {
						if(write_to_fd(fd, "/", 1) < 0)
							return -1;
					}
				}
			}
		}
	}
#endif

	return write_to_fd(fd, "\r\n", 2);
}
