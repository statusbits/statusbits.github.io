/* virtual targets in the ftp daemon.
 *
 * Copyright (C) 1999-2005 Axis Communications AB
 *
 * This file is distributed under the Gnu Public License (GPL),
 * please see the file LICENSE for further information.
 *
 * the configuration file /etc/vftpd.conf defines all virtual targets.
 * Transfer <virtual path> <socket path>
 * Cgi <virtual path> <cgi-bin path>
 */

#include "virtual_target.h"
#include <sys/uio.h>

#define DEBUG(x)

/* simulate HTTP behaviour */
const char ftpmethod_put[] = "FTP_METHOD=PUT";
const char ftpmethod_get[] = "FTP_METHOD=GET";

/* virtual target definitions list */
struct virtual_target *vtargets = NULL;

/* read the configuration file and populate the virtual target list */
void set_virtual_targets(void);

/* return a file descriptor connected to the data channel or -1 on
   fatal error, outparameter is the control channels statfd1 and statfd2 */
static int virtual_cgi(struct virtual_target *vt, const int mode, int *statfd1,
		       int *statfd2);

/* return a file descriptor connected to the data channel or -1 on
   fatal error */
static int virtual_transfer(struct virtual_target *vt);

/* return a pointer to a virtual target if it exists or NULL */
static struct virtual_target *find_virtual(char *path);

/* split an absolute path with space separated arguments s into an argv[]
   and return 0. return -1 if the string is too long or if malloc fails.
   the heap memory is not returned. */
static int set_argv(char s[], char *argv[]);

/* if the path is executable by the effective user logged in return 0.
   return -1 on fatal errors or if non-executable. */
static int is_executable(const char *path);

/* read the configuration file and populate the virtual target list */
void
set_virtual_targets(void)
{
	FILE *f;
	char buf[200];
	struct virtual_target *targ;
	char *s;
	char *b;

	f = fopen(VTARGET_FILE, "r");
	if (f == NULL) {
		/* non-existence is not a fatal error  */
		syslog(LOG_WARNING, "%s not found", VTARGET_FILE);
		return;
	}

	while (fgets(buf, sizeof(buf), f)) {
		if (strncmp(buf, TRANSFER_TOKEN, strlen(TRANSFER_TOKEN)) == 0
		    || strncmp(buf, CGI_TOKEN, strlen(CGI_TOKEN)) == 0) {
			targ = (struct virtual_target *)
				malloc(sizeof(struct virtual_target));
			if (targ == NULL) {
				syslog(LOG_ERR, "set_virtual_targets: "
						"Memory allocation failed. %m");
				exit(1);
			}
			if (*buf == 'T') {
				targ->type = VIRT_TRANSFER;
				b = buf + strlen(TRANSFER_TOKEN);
			} else if (*buf == 'C') {
				targ->type = VIRT_CGI;
				b = buf + strlen(CGI_TOKEN);
			} else {
				syslog(LOG_ERR, "set_virtual_targets: "
				       "Bad type: %s\n", buf);
				continue;
			}

			/* get the virtual path referenced in FTP */
			s = strtok(b, " ");
			if (s == NULL) {
				syslog(LOG_ERR, "set_virtual_targets: %s\n",
				       buf);
				continue;
			}
			/* get the file system path to the cgi-bin */
			targ->virtual = strdup(s);
			s = strtok(NULL, "\r\n");
			targ->real = strdup(s);
			/* none set yet */
			targ->transfer_fd = -1;

			/* add to linked list */
			targ->next = vtargets;
			vtargets = targ;

			DEBUG(fprintf(stderr, "set_virtual_target: %d %s %s\n",
				      targ->type, targ->virtual, targ->real));
		}
	}
	fclose(f);
}

/* return 0 if the virtual target path does not exist, -1 on fatal error,
   and a file descriptor connected to the data channel if the virtual
   target path is an executable absolute path. outparameters are the
   type of virtual target and the control channels statfd1 and statfd2 for the
   cgi type. statfd1 (before data channel is opened) is optional, if it's
   NULL, only statfd2 will be used throughout the whole session */
int
open_virtual(char *path, const int amode, int *virtual_type, int *statfd1,
	     int *statfd2)
{
	struct virtual_target *vt;
	int retfd;

	DEBUG(fprintf(stderr, "open_virtual: %s %d\n", path, amode));

	/* return 0 and set virtual_type to NO_VIRT if the virtual target path is not found */
	vt = find_virtual(path);
	if (vt == NULL) {
		*virtual_type = NO_VIRT;
		return 0;
	}

	/* this is required in the cgi execution */
	*virtual_type = vt->type;

	if (vt->type == VIRT_TRANSFER) {
		/* virtual transfer does not need to send to the client */
		if (statfd1){
			*statfd1 = -1;
		}
		*statfd2 = -1;
		retfd = virtual_transfer(vt);
	} else if (vt->type == VIRT_CGI) {
		/* retfd is the data channel, statfd the control channel */
		retfd = virtual_cgi(vt, amode, statfd1, statfd2);
	} else {
		syslog(LOG_ERR, "open_virtual: Bad virtual target type [%d]",
		       vt->type);
		if (statfd1){
			*statfd1 = -1;
		}
		*statfd2 = -1;
		retfd = -1;
	}
	return retfd;
}

/* return a file descriptor connected to the data channel or -1 on
   fatal error, outparameter is the control channels statfd1 and statfd2,
   statfd1 (before data channel is opened) is optional, if it's NULL, only
   statfd2 will be used throughout the whole session */
static int
virtual_cgi(struct virtual_target *vt, const int mode, int *statfd1,
	    int *statfd2)
{
	int retfd = -1;
	char *argv[128];
	int pdata[2];
	int pctrl1[2];
	int pctrl2[2];
	const char *ftpmethodenv;
	char virtenv[80];
	char *envp[] = { NULL, NULL, NULL };
	int pid;

	/* get program name and arguments */
	if (set_argv(vt->real, argv) == -1) {
		return -1;
	}
	/* is it executable by the user/group */
	if (is_executable(argv[0]) < 0) {
		return -1;
	}

	/* pipe[0] is for reading, pipe[1] is for writing */
	if (pipe(pdata) < 0 || pipe(pctrl2)) {
		syslog(LOG_ERR, "virtual_cgi: Failed to create pipe %m");
	}

	if (statfd1 && pipe(pctrl1)) {
		syslog(LOG_ERR, "virtual_cgi: Failed to create pipe %m");
	}

	/* set environment variables FTP_METHOD (PUT, GET) based on mode */
	if (mode == O_RDONLY) {
		ftpmethodenv = ftpmethod_get;
	} else if (mode == O_WRONLY) {
		ftpmethodenv = ftpmethod_put;
	} else {
		syslog(LOG_ERR, "virtual_cgi: Bad mode [%d]\n", mode);
		return -1;
	}

	if ((pid = fork()) < 0) {
		syslog(LOG_ERR, "virtual_cgi: Failed to fork. (error %d: %m)",
		       errno);
		return -1;
	} else if (pid > 0) {
		/* in parent */
		if (mode == O_RDONLY) {
			/* reading from stdout in child */
			retfd = pctrl2[0];
			/* no write */
			close(pctrl2[1]);

			/* writing to stdin in child by pdata[1] */
			*statfd2 = pdata[1];
			/* no read */
			close(pdata[0]);
		} else if (mode == O_WRONLY) {
			if (statfd1) {
				/* reading from stdout in child */
				*statfd1 = pctrl1[0];
				/* no write */
				close(pctrl1[1]);
			}

			/* reading from stdout in child */
			*statfd2 = pctrl2[0];
			/* no write */
			close(pctrl2[1]);

			/* writing to stdin in child by pdata[1] */
			retfd = pdata[1];
			/* no read */
			close(pdata[0]);
		}
	} else {
		/* in child */
		/* writing to control connection in parent */
		if (dup2(pctrl2[1], STDOUT_FILENO) != STDOUT_FILENO) {
			syslog(LOG_ERR, "virtual_cgi: Failed writing to "
			       "control connection in parent. "
			       "(dup2 error %d, %m)", errno);
			return -1;
		}
		close(pctrl2[1]);
		/* no read */
		close(pctrl2[0]);

		/* reading from data connection in parent */
		if (dup2(pdata[0], STDIN_FILENO) != STDIN_FILENO) {
			syslog(LOG_ERR, "virtual_cgi: Failed reading from "
			       "data connection in parent. (dup2 error %d, %m)",
			       errno);
			return -1;
		}
		close(pdata[0]);
		/* no write */
		close(pdata[1]);

		if (statfd1) {
			/* writing to control connection in parent */
			if (dup2(pctrl1[1], 3) != 3) {
				syslog(LOG_ERR, "virtual_cgi: Failed writing "
				       "to control connection in parent. "
				       "(dup2 error %d, %m)", errno);
				return -1;
			}
			close(pctrl1[1]);
			/* no read */
			close(pctrl1[0]);
		}

		strcpy(virtenv, "VIRTUAL=");
		strcat(virtenv, vt->virtual);
		envp[0] = virtenv;
		envp[1] = (char *)ftpmethodenv;
		execve(argv[0], argv, envp);
		/* execve failed */
		syslog(LOG_ERR, "execve %s failed: %s", vt->real,
		       strerror(errno));
		return -1;
	}
	return retfd;
}

/* return a data channel file descriptor or -1 on fatal error */
static int
virtual_transfer(struct virtual_target *vt)
{
	int vpipe[2];
	int childfd;
	int retfd;
	int transfer_fd;
	char query[1];
	char uribuf[100];
	struct iovec iov[2];

	/* a transfer is handled by giving away the other end of the pipe
	 * through the fd-transfer mechanism in AF_UNIX sockets
	 */

	DEBUG(fprintf(stderr, "virtual_transfer: found VIRT_TRANSFER\n"));

	/* NOTE: we could probably have used pipe()'s here as well, but
	 * since the deamon in the other end expects a real socket, we
	 * might as well give it what it wants using socketpair() instead.
	 */

	if (socketpair(AF_UNIX, SOCK_STREAM, 0, vpipe) < 0) {
		syslog(LOG_ERR, "Failed to create a pair of connected sockets. %m");
		return -1;
	}

	/* socketpair() sockets are identical; it does not matter which one
	 * is read or written to
	 */

	childfd = vpipe[0];
	retfd = vpipe[1];

	/* NOTE: since we have forked at this point, we need to get the
	 * send_socket each time a request comes because we cannot save it
	 * back into the parents vt structure. fix this by letting main()
	 * do get_send_socket on each virtual transfer before starting.
	 */

	if ((transfer_fd = fdipc_client_socket(vt->real)) < 0)
		return -1;

	/* the query string contains additional parameters that
	 * are not used right now, but might be configured in the
	 * /etc/vftpd.conf file in the future for each Transfer.
	 */

	query[0] = 0;

	DEBUG(fprintf(stderr, "virtual_transfer: sending uri %s, query %s\n",
		      vt->virtual, query));

	strcpy(uribuf, "ftp:/");   /* a slash is in vt->virtual already */
	strncat(uribuf, vt->virtual, 95);

	iov[0].iov_base = uribuf;		/* request URI */
	iov[0].iov_len = strlen(uribuf) + 1;    /* include 0 separator */
	iov[1].iov_base = query;		/* query specifications */
	iov[1].iov_len = strlen(query) + 1;	/* include 0 end */

	if (fdipc_send(transfer_fd, iov, 2, childfd) < 0) {
		close(transfer_fd);
		return -1;
	}

	close(transfer_fd);

	/* close the child part of the pipe, otherwise we won't get an
	 * EOF on the other end of the pipe when the child exits.
	 */

	close(childfd);

	return retfd;
}

/* return a pointer to a virtual target if it exists or NULL, change a
   relative path into an absolute path if necessary. */
static struct virtual_target *
find_virtual(char *path)
{
	static char buf[MAX_PATH_LENGTH];
	struct virtual_target *vt;

	DEBUG(fprintf(stderr, "find_virtual: %s\n", path));

	/* create an absolute path from the current working directory
	   if path is a relative path */
	if (*path != '/') {
		if (!getcwd(buf, MAX_PATH_LENGTH - MAX_NAME_LENGTH))
			return NULL;  /* too long cwd... */
		DEBUG(fprintf(stderr, "getcwd: %s\n", buf));
		if (strlen(buf) > 1)
			strcat(buf, "/");
		if (strlen(path) >= MAX_NAME_LENGTH) {
			syslog(LOG_ERR, "find_virtual: too long name");
			return NULL;
		}
		/* FIXME not very nice for a consecutive free */
		strcat(buf, path);
		path = buf;
	}

	/* is the absolute path a known virtual target */
	vt = vtargets;
	while (vt) {
		DEBUG(fprintf(stderr, "%s == %s\n", vt->virtual, path));
		if (strcmp(vt->virtual, path) == 0) {
			return vt;
		}
		vt = vt->next;
	}
	/* not a virtual target */
	return NULL;
}

/* split an absolute path with space separated arguments s into an argv[]
   and return 0. return -1 if the string is too long or if malloc fails.
   the heap memory is not returned. */
static int
set_argv(char s[], char *argv[])
{
	int i;
	char *token;
	char *token_next;
	int len;
	char *arg;

	/* index in argv */
	i = 0;
	/* token points to first non-space of an argument */
	token = s;
	while (*token != '\0') {
		/* find next token or the end of the string */
		token_next = strchr(token, ' ');
		if (token_next == NULL) {
			token_next = strchr(token, '\0');
		}
		/* save the token */
		len = token_next - token + 1;
		if (len > MAX_CMD_LENGTH) {
			syslog(LOG_ERR, "set_argv: too long argv");
			return -1;
		}
		if ((arg = malloc(len)) == NULL) {
			syslog(LOG_ERR, "set_argv: Memory allocation failed. "
					  "%m");
			return -1;
		}
		strncpy(arg, token, token_next - token);
		arg[token_next - token] = '\0';
		argv[i] = arg;
		DEBUG(fprintf(stderr, "set_argv argv[%d]: %s\n", i, argv[i]));
		i++;
		/* skip space */
		while (*token_next == ' ') {
			token_next++;
		}
		token = token_next;
	}
	/* null terminate the argument vector */
	argv[i] = NULL;
	return 0;
}

/* if the path is executable by the effective user logged in return 0.
   return -1 on fatal errors or if non-executable. */
static int
is_executable(const char *path)
{
	int retval = 0;
	uid_t euid;
	gid_t egid;

	/* get effective id */
	euid = geteuid();
	egid = getegid();

	/* check access rights by real id */
	if (setreuid(euid, euid) < 0) {
		retval = -1;
	}
	if (setregid(egid, egid) < 0) {
		retval = -1;
	}
	if (access(path, R_OK | X_OK) < 0) {
		DEBUG(fprintf(stderr, "%s\n", strerror(errno)));
		retval = -1;
	}
	return retval;
}
