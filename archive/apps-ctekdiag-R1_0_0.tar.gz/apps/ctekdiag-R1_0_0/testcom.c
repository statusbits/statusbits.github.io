#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <termios.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <string.h>

#define Pad_DTR		2
#define Pad_DCD		0x40

void *to_radio (void *arg);
void *from_radio (void *arg);
void *loop_to_radio (void *arg);

typedef unsigned char U8;

void dput (U8 dbyte);

char port_in[5] = { "2" };
char port_out[5] = { "3" };
char asc_hex[5] = { "a" };	// a for ascii h for hex
char speed[5] = { "4" };
char floctl[5] = { "n" };	// f for flow control n for no flow control
char dtrdcd[5] = { "0" };
char dtrctl[5] = { "0" };

int ci_fd, co_fd, escape;
int line_stat, loop_count, loop_error;
struct termios ci_cfg, co_cfg, c1_cfg, c1_bak;
speed_t spd[6] = { B9600, B19200, B38400, B57600, B115200, B230400 };

int spd_index, pi_index, po_index, loop = 0;

//
// radio_com {port in}   {port out}   {[a]scii,[h]ex}   {speed [0] 9600 - [5] 230400}   {flow control [f] on  [n] off}
// 

int
main (int argc, char **argv)
{

  char port[10][14] = { "/dev/ttyS0",
    "/dev/ttyS1",
    "/dev/ttyS2",
    "/dev/ttyS3",
    "/dev/ttyUSB0",
    "/dev/ttyUSB1",
    "/dev/ttyUSB2",
    "/dev/ttyUSB3",
    "/dev/ttyUSB4",
    "/dev/ttyUSB5"
  };

  int rstat;
  pthread_t loop_thread;
  pthread_t tr_thread;
  pthread_t fr_thread;
  pthread_attr_t thread_attr;


  if (argc != 8)
    {
      printf ("\n\n********************************** RADIO COM COMMAND FORMAT *********************************\n\n");
      printf ("radio_com  <input port> <output port> <ascii/hex> <speed> <flow control> <DTR/DCD output port test> \n\n");
      printf ("input port:      0 = ttyS0, 1 = ttyS1, 2 = ttyS2, 3 = ttyS3, 4 = USB0, 5 = USB1, 6 = USB2, 7 = USB3, 8 = USB4, 9 = USB5\n");
      printf ("output port:     0 = ttyS0, 1 = ttyS1, 2 = ttyS2, 3 = ttyS3, 4 = USB0, 5 = USB1, 6 = USB2, 7 = USB3, 8 = USB4, 9 = USB5\n");
      printf ("asci/hex:        a = ascii, h = hex \n");
      printf ("speed:           0 = 9600, 1 = 19200, 2 = 38400, 3 = 57600, 4 = 115200, 5 = 230400 \n");
      printf ("flow control:    f = rts/cts flow control,  n = no rts/cts flow control \n");
      printf ("DTR/DCD Test:    0 = Don't test,  1 = Test that DCD follows DTR (requires loop back) \n\n");
      printf ("DTR Control :    0 = Control off,  1 = Control on \n\n");
      printf ("*********************************************************************************************\n\n");
      exit (EXIT_FAILURE);
    }

  strcpy (port_in, argv[1]);
  strcpy (port_out, argv[2]);
  strcpy (asc_hex, argv[3]);
  strcpy (speed, argv[4]);
  strcpy (floctl, argv[5]);
  strcpy (dtrdcd, argv[6]);
  strcpy (dtrctl, argv[7]);


  pi_index = port_in[0] & 0x0F;
  po_index = port_out[0] & 0x0F;
  spd_index = speed[0] & 0x0F;

  if ((ci_fd = open (port[pi_index], O_RDWR)) == -1)
    {
      perror ("Cannot open com in port");
      exit (EXIT_FAILURE);
    }

  if (pi_index == po_index)
    co_fd = ci_fd;
  else
    {
      if ((co_fd = open (port[po_index], O_RDWR)) == -1)
	{
	  perror ("Cannot open com out port");
	  exit (EXIT_FAILURE);
	}
    }


  printf ("**********  TESTCOM  *********\n");
  printf ("****                      ****\n");
  printf ("****   To exit type ~~~   ****\n");
  printf ("****                      ****\n");

/*
  if(dtrdcd[0] == '1')
  {
     printf("****  DTR/DCD Loop Test   ****\n");
     for(loop_count = 0, loop_error = 0; (loop_count < 6) && (loop_error == 0); loop_count++)
     {

     
        line_stat = TIOCM_DTR;
        ioctl (co_fd, TIOCMBIS, &line_stat);

        ioctl (co_fd, TIOCMGET, &line_stat);


        if(line_stat & TIOCM_CD)
        {
           line_stat = TIOCM_DTR;
           ioctl (co_fd, TIOCMBIC, &line_stat);
           ioctl (co_fd, TIOCMGET, &line_stat);

           if(line_stat & TIOCM_CD)
             loop_error = 1;
         }
        else
           loop_error = 1;  
     }
     if(loop_error)
        printf("****  DTR/DCD loop FAIL   ****\n");
     else
        printf("****  DTR/DCD loop PASS   ****\n");

  } 
   
*/

  // Configure input port -----------------------------------------

  tcgetattr (ci_fd, &ci_cfg);
  cfsetospeed (&ci_cfg, spd[spd_index]);
  cfsetispeed (&ci_cfg, spd[spd_index]);
  ci_cfg.c_cc[VMIN] = 1;
  ci_cfg.c_cc[VTIME] = 0;
  ci_cfg.c_oflag &= ~OPOST;
  ci_cfg.c_lflag &= ~(IEXTEN | ICANON | ISIG | ECHO);
  ci_cfg.c_iflag &= ~(IXON | IXOFF | ICRNL | ISTRIP | INLCR);

  if (floctl[0] == 'n')
    {
      printf ("***** Flow control is off ****\n");
      ci_cfg.c_cflag &= ~CRTSCTS;
    }
  else
    {
      ci_cfg.c_cflag |= CRTSCTS;
      printf ("***** Flow control is on *****\n");
    }
  tcsetattr (ci_fd, TCSANOW, &ci_cfg);

  // Configure output port -----------------------------------------

  if (pi_index != po_index)
    {
      tcgetattr (co_fd, &co_cfg);
      cfsetospeed (&co_cfg, spd[spd_index]);
      cfsetispeed (&co_cfg, spd[spd_index]);
      co_cfg.c_cc[VMIN] = 1;
      co_cfg.c_cc[VTIME] = 0;
      co_cfg.c_oflag &= ~OPOST;
      co_cfg.c_lflag &= ~(IEXTEN | ICANON | ISIG | ECHO);
      co_cfg.c_iflag &= ~(IXON | IXOFF | ICRNL | ISTRIP | INLCR);

      if (floctl[0] == 'n')
	co_cfg.c_cflag &= ~CRTSCTS;
      else
	co_cfg.c_cflag |= CRTSCTS;
      tcsetattr (co_fd, TCSANOW, &co_cfg);
    }
  printf ("******************************\n");

  // Configure std io ----------------------------------------------

  tcgetattr (0, &c1_cfg);
  tcgetattr (0, &c1_bak);
  cfsetospeed (&c1_cfg, B115200);
  cfsetispeed (&c1_cfg, B115200);
  c1_cfg.c_cc[VMIN] = 1;
  c1_cfg.c_cc[VTIME] = 0;
  c1_cfg.c_oflag &= ~OPOST;
  c1_cfg.c_lflag &= ~(IEXTEN | ICANON | ISIG | ECHO);
  c1_cfg.c_iflag &= ~(IXON | IXOFF | ICRNL | ISTRIP | INLCR);
  tcsetattr (0, TCSANOW, &c1_cfg);

  pthread_attr_init (&thread_attr);
  pthread_attr_setdetachstate (&thread_attr, PTHREAD_CREATE_DETACHED);


  // Start program threads -----------------------------------------------

  rstat = pthread_create (&tr_thread, &thread_attr, to_radio, (void *) NULL);
  if (rstat != 0)
    {
      perror ("TR Thread create failed");
      exit (EXIT_FAILURE);
    }

  rstat = pthread_create (&fr_thread, &thread_attr, from_radio, (void *) NULL);
  if (rstat != 0)
    {
      perror ("FR Thread create failed");
      exit (EXIT_FAILURE);
    }

  rstat = pthread_create (&loop_thread, &thread_attr, loop_to_radio, (void *) NULL);
  if (rstat != 0)
    {
      perror ("Loop Thread create failed");
      exit (EXIT_FAILURE);
    }



  for (escape = 0; escape < 3;)
    sleep (2);

  close (ci_fd);
  if (pi_index != po_index)
    close (co_fd);
  tcsetattr (0, TCSANOW, &c1_bak);
  pthread_cancel (tr_thread);
  pthread_cancel (fr_thread);
  pthread_cancel (loop_thread);

  exit (EXIT_SUCCESS);
}


//
//  Send data do a radio port
//

void *
to_radio (void *arg)
{

  ssize_t count, wcount;
  char data[5], x;


  pthread_setcancelstate (PTHREAD_CANCEL_ENABLE, NULL);
  pthread_setcanceltype (PTHREAD_CANCEL_ASYNCHRONOUS, NULL);

  for (;;)
    {
      count = read (0, data, 1);
      if (count == -1)
	tcflush (0, TCIFLUSH);
      else if (count != 0)
	{
	  if (data[0] == '>')
	    loop = 1;
	  else if (data[0] == '<')
	    loop = 0;
	  else if (data[0] == '~')
	    escape++;
	  else
	    {
	      if (dtrctl[0] == '1')
		{
		  x = 1;
		  if (data[0] == '^')
		    {
		      line_stat = TIOCM_DTR;
		      ioctl (co_fd, TIOCMBIS, &line_stat);
		    }
		  else if (data[0] == '%')
		    {
		      line_stat = TIOCM_DTR;
		      ioctl (co_fd, TIOCMBIC, &line_stat);
		    }
		  else if (data[0] == '*')
		    {
		      line_stat = TIOCM_RTS;
		      ioctl (co_fd, TIOCMBIS, &line_stat);
		    }
		  else if (data[0] == '&')
		    {
		      line_stat = TIOCM_RTS;
		      ioctl (co_fd, TIOCMBIC, &line_stat);
		    }
		  else
		    x = 0;
		  if (x)
		    {
		      ioctl (co_fd, TIOCMGET, &line_stat);
		      if (line_stat & TIOCM_CD)
			printf ("CD = 1 ");
		      else
			printf ("CD = 0 ");

		      if (line_stat & TIOCM_CTS)
			printf ("CTS = 1 ");
		      else
			printf ("CTS = 0 ");

		      if (line_stat & TIOCM_DSR)
			printf ("DSR = 1\n\r");
		      else
			printf ("DSR = 0\n\r");
		    }
		}
	      else
		x = 0;
	      if (x == 0)
		{
		  escape = 0;
		  if (!loop)
		    {
		      wcount = write (co_fd, data, count);
		      if (wcount == -1)
			tcflush (co_fd, TCOFLUSH);
		    }
		}
	    }
	}
    }
}


//
//  Send canned blocks of data to radio
//

void *
loop_to_radio (void *arg)
{

  int x;
  ssize_t wcount;
  char canned_data[100] = { "0000 - 1234567890abcdefghijhlmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890\x0d\x0a" };

  pthread_setcancelstate (PTHREAD_CANCEL_ENABLE, NULL);
  pthread_setcanceltype (PTHREAD_CANCEL_ASYNCHRONOUS, NULL);

  for (;;)
    {

      while (loop)
	{
	  wcount = write (co_fd, canned_data, strlen (canned_data));
	  if (wcount == -1)
	    tcflush (co_fd, TCOFLUSH);

	  x = 4;
	  while (x != 0)
	    {
	      x--;
	      if (++canned_data[x] > '9')
		canned_data[x] = '0';
	      else
		x = 0;
	    }
	}
      for (x = 0; x < 4; x++)
	canned_data[x] = '0';
      sleep (1);
    }
}



//
// Get data from radio port
//

void *
from_radio (void *arg)
{
  ssize_t count;
  ssize_t wcount;
  char data[5];

  pthread_setcancelstate (PTHREAD_CANCEL_ENABLE, NULL);
  pthread_setcanceltype (PTHREAD_CANCEL_ASYNCHRONOUS, NULL);

  for (;;)
    {
      count = read (ci_fd, data, 1);
      if (count == -1)
	{
	  tcflush (ci_fd, TCIFLUSH);
	}
      else if (count != 0)
	{

	  if (asc_hex[0] == 'h')
	    dput (data[0]);
	  else
	    wcount = write (1, data, 1);
	  if (wcount == -1)
	    tcflush (1, TCOFLUSH);
	}
    }
}





void
dput (U8 dbyte)
{
  ssize_t wcount;
  static U8 hex_byte, flag = 0;

  hex_byte = (dbyte & 0xf0) >> 4;
  if (hex_byte < 0x0A)
    hex_byte += 0x30;
  else
    hex_byte += 0x37;
  wcount = write (1, &hex_byte, 1);
  hex_byte = (dbyte & 0x0f);
  if (hex_byte < 0x0A)
    hex_byte += 0x30;
  else
    hex_byte += 0x37;
  wcount = write (1, &hex_byte, 1);
  if (wcount == -1)
    tcflush (1, TCOFLUSH);
  if (dbyte == 0x7E)
    {
      if (flag == 1)
	{
	  write (1, "\n\r", 2);
	  flag = 0;
	}
      else
	flag = 1;
    }
  return;
}
