#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <termios.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <string.h>

#define Pad_DTR		2
#define Pad_DCD		0x40


typedef unsigned char U8;

void dput (U8 dbyte);

char port_in[5] = { "1" };
char port_out[5] = { "2" };
char asc_hex[5] = { "a" };	// a for ascii h for hex
char speed[5] = { "2" };
char floctl[5] = { "n" };	// f for flow control n for no flow control
char dtrdcd[5] = { "0" };
char dtrctl[5] = { "0" };

int ci_fd, co_fd, escape;
int line_stat, loop_count, loop_error;
struct termios ci_cfg, co_cfg, c1_cfg, c1_bak;

int spd_index, pi_index, po_index, loop = 0;

//
// radio_com {port in}   {port out}   {[a]scii,[h]ex}   {speed [0] 9600 - [5] 230400}   {flow control [f] on  [n] off}
// 

int
main (int argc, char **argv)
{

  int stat;
  char data[20] = { "TEST MESSAGE 0\x0A\x0D" };

  pi_index = port_in[0] & 0x0F;
  po_index = port_out[0] & 0x0F;
  spd_index = speed[0] & 0x0F;

  if ((ci_fd = open ("/dev/ttyS1", O_WRONLY)) == -1)
    {
      perror ("Cannot open com in port");
      exit (EXIT_FAILURE);
    }

  if ((co_fd = open ("/dev/ttyS2", O_WRONLY)) == -1)
    {
      perror ("Cannot open com out port");
      exit (EXIT_FAILURE);
    }


  system ("ping 192.168.1.111 &");

  system ("ping 192.168.0.111 &");

  // Configure input port -----------------------------------------

  tcgetattr (ci_fd, &ci_cfg);
  cfmakeraw (&ci_cfg);
  cfsetospeed (&ci_cfg, B38400);
  cfsetispeed (&ci_cfg, B38400);
  ci_cfg.c_cc[VMIN] = 0;
  ci_cfg.c_cc[VTIME] = 0;
//  ci_cfg.c_oflag &= ~OPOST;
//  ci_cfg.c_lflag &= ~(IEXTEN | ICANON | ISIG | ECHO);
//  ci_cfg.c_iflag &= ~(IXON | IXOFF | ICRNL | ISTRIP | INLCR);
  ci_cfg.c_cflag &= ~CRTSCTS;
  ci_cfg.c_cflag |= CLOCAL;
  tcsetattr (ci_fd, TCSANOW, &ci_cfg);

  // Configure output port -----------------------------------------


  tcgetattr (co_fd, &co_cfg);
  cfmakeraw (&co_cfg);
  cfsetospeed (&co_cfg, B38400);
  cfsetispeed (&co_cfg, B38400);
  co_cfg.c_cc[VMIN] = 0;
  co_cfg.c_cc[VTIME] = 0;
//     co_cfg.c_oflag &= ~OPOST;
//     co_cfg.c_lflag &= ~(IEXTEN | ICANON | ISIG | ECHO);
//     co_cfg.c_iflag &= ~(IXON | IXOFF | ICRNL | ISTRIP | INLCR);
  co_cfg.c_cflag &= ~CRTSCTS;
  co_cfg.c_cflag |= CLOCAL;
  tcsetattr (co_fd, TCSANOW, &co_cfg);



  for (;;)
    {

      stat = write (co_fd, data, strlen (data));


      stat = write (ci_fd, data, strlen (data));


      data[13]++;
      if (data[13] > '9')
	data[13] = '0';
      sleep (2);

    }

}
