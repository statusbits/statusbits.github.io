#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <termios.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/reboot.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>



int
main (int argc, char **argv)
{

  int UDP_fd;
  struct sockaddr_in mac_server, from_addr;
  ssize_t reply_len;
  socklen_t from_len;
  char ubuf[10];
  char cbuf[100];
  char build_type;

  int x, y, z, err, c_fd, c1_fd;

  char port[4][11] = {
    "/dev/ttyS1",
    "/dev/ttyS2",
    "/dev/ttyS3",
    "/dev/ttyS4"
  };

#define tstmsglen   13
#define tstmsgidx   11
  char tstmsg[14] = { "1234567890[ ]" };
  char rcvmsg[14] = { "" };

  struct termios c_cfg;
  struct termios c1_cfg;



  UDP_fd = socket (AF_INET, SOCK_DGRAM, 0);
  fcntl (UDP_fd, F_SETFL, O_NONBLOCK);
  bzero (&mac_server, sizeof (mac_server));
  mac_server.sin_family = AF_INET;
  mac_server.sin_port = htons (5324);
  inet_pton (AF_INET, "192.168.1.190", &mac_server.sin_addr);
  bzero (&from_addr, sizeof (from_addr));
  from_addr.sin_family = AF_INET;

  sendto (UDP_fd, "??", 3, 0, (struct sockaddr *) &mac_server, sizeof (mac_server));
  for (x = 0, reply_len = -1; (x <= 5) && (reply_len == -1); x++)
    {
      sleep (2);
      from_len = sizeof (from_addr);
      reply_len = recvfrom (UDP_fd, ubuf, sizeof (ubuf), 0, (struct sockaddr *) &from_addr, &from_len);
      if (reply_len != -1)
	{
	  if ((reply_len == 4) && (from_addr.sin_addr.s_addr == mac_server.sin_addr.s_addr) && (ubuf[0] == '>') && (ubuf[1] == '>'))
	    build_type = ubuf[2];
	  else
	    reply_len = -1;
	}
    }
  close (UDP_fd);
  if (reply_len == -1)
    {
      printf ("************************************************\n");
      printf ("***  MAC SERVER IS NOT PROVIDING BUILD TYPE  ***\n");
      printf ("************************************************\n");
      sleep (3);
      exit (EXIT_FAILURE);
    }
  else
    {
      // ***********************************************************
      // STANDARD G6200 TEST AND FLASH
      // ***********************************************************
      if (build_type == '0')
	{
	  sleep (3);
	  printf ("************************************************\n");
	  printf ("**** Starting G6200 Test and Flash Process *****\n");
	  printf ("************************************************\n");
	  sleep (3);
	  strcpy (ubuf, "/prod/ctek");

	  // TEST RS-232 COM PORTS
	  for (x = 0, err = 0; x < 4; x++)
	    {
	      if ((c_fd = open (port[x], O_RDWR)) == -1)
		{
		  printf ("************************************************\n");
		  printf ("*** ERROR 00 ttyS%d *** Cannot open COM port ***\n", x + 1);
		  printf ("************************************************\n");
		  sleep (3);
		  exit (EXIT_FAILURE);
		}


	      // Configure port -----------------------------------------

	      tcgetattr (c_fd, &c_cfg);
	      cfsetospeed (&c_cfg, B38400);
	      cfsetispeed (&c_cfg, B38400);
	      c_cfg.c_cc[VMIN] = 0;
	      c_cfg.c_cc[VTIME] = 10;
	      c_cfg.c_oflag &= ~OPOST;
	      c_cfg.c_lflag &= ~(IEXTEN | ICANON | ISIG | ECHO);
	      c_cfg.c_iflag &= ~(IXON | IXOFF | ICRNL | ISTRIP | INLCR);
	      tcsetattr (c_fd, TCSANOW, &c_cfg);

	      if (x < 2)
		c1_fd = c_fd;
	      else
		{
		  if (x == 2)
		    z = 3;
		  else
		    z = 2;

		  if ((c1_fd = open (port[z], O_RDWR)) == -1)
		    {
		      printf ("************************************************\n");
		      printf ("*** ERROR 00 ttyS%d *** Cannot open COM port ***\n", z + 1);
		      printf ("************************************************\n");
		      sleep (3);
		      exit (EXIT_FAILURE);
		    }


		  // Configure port -----------------------------------------

		  tcgetattr (c1_fd, &c1_cfg);
		  cfsetospeed (&c1_cfg, B38400);
		  cfsetispeed (&c1_cfg, B38400);
		  c1_cfg.c_cc[VMIN] = 0;
		  c1_cfg.c_cc[VTIME] = 10;
		  c1_cfg.c_oflag &= ~OPOST;
		  c1_cfg.c_lflag &= ~(IEXTEN | ICANON | ISIG | ECHO);
		  c1_cfg.c_iflag &= ~(IXON | IXOFF | ICRNL | ISTRIP | INLCR);
		  tcsetattr (c1_fd, TCSANOW, &c1_cfg);
		}


	      for (y = '0'; (y < '9') && (err == 0); y++)
		{
		  strcpy (rcvmsg, "             ");
		  tstmsg[tstmsgidx] = y;
		  write (c_fd, tstmsg, tstmsglen);
		  read (c1_fd, rcvmsg, tstmsglen);
		  if (strcmp (tstmsg, rcvmsg) != 0)
		    {
		      printf ("************************************************\n");
		      printf ("*** ERROR 01 ttyS%d *** Data compare error   ***\n", x + 1);
		      printf ("************************************************\n");
		      sleep (3);
		      exit (EXIT_FAILURE);
		    }
		}
	      close (c_fd);
	      if (x > 1)
		close (c1_fd);
	    }

	  z = system ("ping -q -c 5 -W 5 192.168.0.1");
	  if (z != -1)
	    {
	      err = WEXITSTATUS (z);
	      if (err != 0)
		{
		  printf ("************************************************\n");
		  printf ("*** ERROR 03 ETH 1 *** Ping failure          ***\n");
		  printf ("************************************************\n");
		  sleep (3);
		  exit (EXIT_FAILURE);
		}
	    }
	  else
	    {
	      printf ("************************************************\n");
	      printf ("*** ERROR 02 ETH 1 ***  Cannot start ping    ***\n");
	      printf ("************************************************\n");
	      sleep (3);
	      exit (EXIT_FAILURE);
	    }


	}
      // ***********************************************************
      // COOPER  UPGRADE STD G6200 TO G6200XC1 
      // ***********************************************************
      else if (build_type == '3')
	{
	  sleep (3);
	  printf ("************************************************\n");
	  printf ("** Starting G6200 Upgrade to Cooper G6200XC1  **\n");
	  printf ("************************************************\n");
	  sleep (3);
	  strcpy (ubuf, "/prod/cooper");
	}
      else
	{
	  printf ("************************************************\n");
	  printf ("***           UNKNOWN BUILD TYPE             ***\n");
	  printf ("************************************************\n");
	  sleep (3);
	  exit (EXIT_FAILURE);
	}
    }



  system ("flash_erase /dev/mtd0 0x00060000, 2");

  strcpy (cbuf, "nandwrite -s 0x00060000 /dev/mtd0 ");
  strcat (cbuf, ubuf);
  strcat (cbuf, "/ubootEnvtFileNandFlash.bin");
  system (cbuf);

  strcpy (cbuf, "nandwrite -s 0x00080000 /dev/mtd0 ");
  strcat (cbuf, ubuf);
  strcat (cbuf, "/ubootEnvtFileNandFlash.bin");
  system (cbuf);

  strcpy (cbuf, "nandwrite -p -s 0x00200000 /dev/mtd0 ");
  strcat (cbuf, ubuf);
  strcat (cbuf, "/arm-linux-2.6.27.gz");
  system (cbuf);

  strcpy (cbuf, "nandwrite -p -s 0x00000000 /dev/mtd1 ");
  strcat (cbuf, ubuf);
  strcat (cbuf, "/rootfs.arm_nofpu.jffs2");
  system (cbuf);

  system ("mount -t jffs2 /dev/mtdblock1 /mnt");

  strcpy (cbuf, "cp ");
  strcat (cbuf, ubuf);
  strcat (cbuf, "/g6200finaltest /mnt/etc/init.d/S99finaltest");
  system (cbuf);

  system ("umount /mnt");

  sleep (5);

  reboot (RB_AUTOBOOT);

  exit (EXIT_SUCCESS);
}
