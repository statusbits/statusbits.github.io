#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/sem.h>
#include <sys/ipc.h>
#include <sys/types.h>
// Modes of operation -  used mdl_msg operation and local update_mode 
#define mode_flash_and_test	'0'
#define mode_update		'1'

// Define the type field that is in the model file along with model name
#define model_type_z4xxx_no_rdo		'0'
#define model_type_z4xxx_5728_vz	'1'
#define model_type_z4xxx_5728_sp	'2'
#define model_type_z4xxx_8790		'3'
#define model_type_g62xx		'a'
#define model_type_g63xx		'k'

// Define model structure lengths
#define max_model_len  21
#define max_valid_models 30
#define max_valid_boards 5

// Message used to tell target diagnositc and programming code what to do
struct model_msg
{
   char model[max_model_len];
   char board[11];
   char type[2];
   char operation;
};


// Mesage format sent by target programming code
struct mac_msg
{
  char esnh[9];
  char esnd[13];
  char mac[13];
  char mac2[13];
  char meidh[18];
  char meidd[24];
  char imeid[24];
  char model[10];
  char board[11];
  char type[10];
  char release[10];
  char rdomfg[21];
  char rdomdl[11];
  char rdofw[21];
  char rdohw[21];
  char rdoprl[11];
  char sernum[11];
};

