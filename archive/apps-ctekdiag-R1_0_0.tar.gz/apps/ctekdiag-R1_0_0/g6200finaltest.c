#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <termios.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/reboot.h>
int
main (int argc, char **argv)
{

  int fd, x, y, UDP_fd;

  struct sockaddr_in mac_server, from_addr;
  ssize_t reply_len;
  socklen_t from_len;

  static struct mac_msg
  {
    char esnh[9];
    char esnd[13];
    char mac[13];
    char meidh[18];
    char meidd[24];
    char imeid[24];
    char model[10];
    char type[10];
    char release[10];
    char rdomfg[21];
    char rdomdl[11];
    char rdofw[21];
    char rdohw[21];
    char rdoprl[11];
  } mm;



  printf ("************************************************\n");
  printf ("*** Starting G6200 Final Test & Configuration **\n");
  printf ("************************************************\n");

  UDP_fd = socket (AF_INET, SOCK_DGRAM, 0);
  fcntl (UDP_fd, F_SETFL, O_NONBLOCK);
  bzero (&mac_server, sizeof (mac_server));
  mac_server.sin_family = AF_INET;
  mac_server.sin_port = htons (5324);
  inet_pton (AF_INET, "192.168.1.190", &mac_server.sin_addr);
  bzero (&from_addr, sizeof (from_addr));
  from_addr.sin_family = AF_INET;

  mm.meidh[0] = 0;
  mm.meidd[0] = 0;
  mm.esnh[0] = 0;
  mm.esnd[0] = 0;
  mm.imeid[0] = 0;
  strcpy (mm.model, "G6200");
  strcpy (mm.release, "1.00.00");
  strcpy (mm.type, "CK801");
  mm.rdomfg[0] = 0;
  mm.rdomdl[0] = 0;
  mm.rdofw[0] = 0;
  mm.rdoprl[0] = 0;
  sendto (UDP_fd, &mm, sizeof (mm), 0, (struct sockaddr *) &mac_server, sizeof (mac_server));
  for (x = 0, reply_len = -1; (x <= 5) && (reply_len == -1); x++)
    {
      sleep (2);
      from_len = sizeof (from_addr);
      reply_len = recvfrom (UDP_fd, &mm, sizeof (mm), 0, (struct sockaddr *) &from_addr, &from_len);
      if ((reply_len != -1) && (from_addr.sin_addr.s_addr != mac_server.sin_addr.s_addr))
	reply_len = -1;
    }
  close (UDP_fd);
  if (reply_len == -1)
    {
      printf ("************************************************\n");
      printf ("*** ERROR 04 Cannot connect with MAC server  ***\n");
      printf ("************************************************\n");
      exit (EXIT_FAILURE);
    }
  else
    {
      system ("mount -t jffs2 /dev/mtdblock4 /mnt");
      fd = open ("/mnt/mac.eth0", O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
      if (fd != -1)
	{
	  write (fd, "MAC=\"", 5);
	  for (x = 0; x < 12; x += 2)
	    {
	      write (fd, &mm.mac[x], 2);
	      if (x == 10)
		write (fd, "\"", 1);
	      else
		write (fd, ":", 1);
	    }
	  write (fd, "\n", 1);
	  close (fd);

	}
      else
	{
	  printf ("************************************************\n");
	  printf ("*** ERROR 05 Cannot create mac.eth0          ***\n");
	  printf ("************************************************\n");
	  exit (EXIT_FAILURE);
	}

      fd = open ("/mnt/mac.eth1", O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
      if (fd != -1)
	{
	  write (fd, "MAC=\"", 5);
	  for (x = 0; x < 12; x += 2)
	    {
	      write (fd, &mm.esnd[x], 2);
	      if (x == 10)
		write (fd, "\"", 1);
	      else
		write (fd, ":", 1);
	    }
	  write (fd, "\n", 1);
	  close (fd);

	}
      else
	{
	  printf ("************************************************\n");
	  printf ("*** ERROR 06 Cannot create mac.eth1          ***\n");
	  printf ("************************************************\n");
	  exit (EXIT_FAILURE);
	}


      fd = open ("/mnt/serno", O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
      if (fd != -1)
	{
	  write (fd, "SERNO=\"", 7);
	  write (fd, mm.meidh, strlen (mm.meidh));
	  write (fd, "\"\n", 2);
	  close (fd);
	}
      else
	{
	  printf ("************************************************\n");
	  printf ("*** ERROR 07 Cannot create mac.eth1          ***\n");
	  printf ("************************************************\n");
	  exit (EXIT_FAILURE);
	}


      system ("umount /mnt");

      printf ("************************************************\n");
      printf ("*** SUCCESS *** Test & Configuration Complete **\n");
      printf ("************************************************\n");
      unlink ("/etc/conf.d/mac.eth0");
      unlink ("/etc/conf.d/mac.eth1");
//      unlink ("/etc/init.d/S99finaltest");
      system ("rm -f /etc/init.d/S99finaltest");
      exit (EXIT_SUCCESS);
    }



}
