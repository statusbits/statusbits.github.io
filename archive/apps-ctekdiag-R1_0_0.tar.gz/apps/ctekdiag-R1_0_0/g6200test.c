#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <termios.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/reboot.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <dirent.h>
#include "macserver.h"

static int get_value (char *key, int src_fd, char *dest, int max_len);

int
main (int argc, char **argv)
{

  int UDP_fd, fd, op_stat;
  struct sockaddr_in mac_server, from_addr;
  ssize_t reply_len;
  socklen_t from_len;
  char ubuf[100];
  char cbuf[100];


  int x, y, z, err, c_fd, c1_fd;

  char port[4][11] = {
    "/dev/ttyS1",
    "/dev/ttyS2",
    "/dev/ttyS3",
    "/dev/ttyS4"
  };

#define tstmsglen   13
#define tstmsgidx   11
  char tstmsg[14] = { "1234567890[ ]" };
  char rcvmsg[14] = { "" };

  struct termios c_cfg;
  struct termios c1_cfg;


  static struct model_msg mdl_msg;
  static struct mac_msg mm;


  UDP_fd = socket (AF_INET, SOCK_DGRAM, 0);
  fcntl (UDP_fd, F_SETFL, O_NONBLOCK);
  bzero (&mac_server, sizeof (mac_server));
  mac_server.sin_family = AF_INET;
  mac_server.sin_port = htons (5324);
  inet_pton (AF_INET, "192.168.1.190", &mac_server.sin_addr);
  bzero (&from_addr, sizeof (from_addr));
  from_addr.sin_family = AF_INET;

  // ******************************************************************
  //  GO TO SERVER AND GET BUILD TYPE
  // ******************************************************************

  for (x = 0, reply_len = -1; (x <= 5) && (reply_len == -1); x++)
    {
      sendto (UDP_fd, "??", 3, 0, (struct sockaddr *) &mac_server, sizeof (mac_server));
      sleep (2);
      from_len = sizeof (from_addr);
      reply_len = recvfrom (UDP_fd, &mdl_msg, sizeof (mdl_msg), 0, (struct sockaddr *) &from_addr, &from_len);
      if (reply_len != -1)
	{
	  if ((reply_len != sizeof (mdl_msg)) && (from_addr.sin_addr.s_addr == mac_server.sin_addr.s_addr))
	    reply_len = -1;
	}
    }

  if (reply_len == -1)
    {
      printf ("************************************************\n");
      printf ("***  MAC SERVER IS NOT PROVIDING BUILD TYPE  ***\n");
      printf ("************************************************\n");
      sleep (3);
      exit (EXIT_FAILURE);
    }
  else
    {
      // ***********************************************************
      // STANDARD G6200 TEST AND FLASH
      // ***********************************************************
      if (mdl_msg.operation == mode_flash_and_test)
	{
	  sleep (3);
	  printf ("************************************************\n");
	  printf ("** Starting Production Test and Flash Process **\n");
	  printf ("************************************************\n");
	  sleep (3);

	  // TEST RS-232 COM PORTS
	  for (x = 0, err = 0; x < 4; x++)
	    {
	      if ((c_fd = open (port[x], O_RDWR)) == -1)
		{
		  printf ("************************************************\n");
		  printf ("*** ERROR 00 ttyS%d *** Cannot open COM port ***\n", x + 1);
		  printf ("************************************************\n");
		  sleep (3);
		  exit (EXIT_FAILURE);
		}


	      // Configure port -----------------------------------------

	      tcgetattr (c_fd, &c_cfg);
	      cfsetospeed (&c_cfg, B38400);
	      cfsetispeed (&c_cfg, B38400);
	      c_cfg.c_cc[VMIN] = 13;
	      c_cfg.c_cc[VTIME] = 10;
	      c_cfg.c_oflag &= ~OPOST;
	      c_cfg.c_lflag &= ~(IEXTEN | ICANON | ISIG | ECHO);
	      c_cfg.c_iflag &= ~(IXON | IXOFF | ICRNL | ISTRIP | INLCR);
	      c_cfg.c_cflag &= ~(CRTSCTS);
	      tcsetattr (c_fd, TCSANOW, &c_cfg);

	      if (x < 2)
		c1_fd = c_fd;
	      else
		{
		  if (x == 2)
		    z = 3;
		  else
		    z = 2;

		  if ((c1_fd = open (port[z], O_RDWR)) == -1)
		    {
		      printf ("************************************************\n");
		      printf ("*** ERROR 00 ttyS%d *** Cannot open COM port ***\n", z + 1);
		      printf ("************************************************\n");
		      sleep (3);
		      exit (EXIT_FAILURE);
		    }


		  // Configure port -----------------------------------------

		  tcgetattr (c1_fd, &c1_cfg);
		  cfsetospeed (&c1_cfg, B38400);
		  cfsetispeed (&c1_cfg, B38400);
		  c1_cfg.c_cc[VMIN] = 13;
		  c1_cfg.c_cc[VTIME] = 10;
		  c1_cfg.c_oflag &= ~OPOST;
		  c1_cfg.c_lflag &= ~(IEXTEN | ICANON | ISIG | ECHO);
		  c1_cfg.c_iflag &= ~(IXON | IXOFF | ICRNL | ISTRIP | INLCR);
		  c1_cfg.c_cflag &= ~(CRTSCTS);
		  tcsetattr (c1_fd, TCSANOW, &c1_cfg);
		}
	    for (y = '0'; (y < '9') && (err == 0); y++)
		{
		  strcpy (rcvmsg, "             ");
		  tstmsg[tstmsgidx] = y;
		  write (c_fd, tstmsg, tstmsglen);
		  read (c1_fd, rcvmsg, tstmsglen);
		  if (strcmp (tstmsg, rcvmsg) != 0)
		    {
		      printf ("************************************************\n");
		      printf ("*** ERROR 01 ttyS%d *** Data compare error   ***\n", x + 1);
		      printf ("************************************************\n");
		      sleep (3);
		      exit (EXIT_FAILURE);
		    }
		}
	      close (c_fd);
	      if (x > 1)
		close (c1_fd);
	    }

	  z = system ("ping -q -c 5 -W 5 192.168.0.1");
	  if (z != -1)
	    {
	      err = WEXITSTATUS (z);
	      if (err != 0)
		{
		  printf ("************************************************\n");
		  printf ("*** ERROR 03 ETH 1 *** Ping failure          ***\n");
		  printf ("************************************************\n");
		  sleep (3);
		  exit (EXIT_FAILURE);
		}
	    }
	  else
	    {
	      printf ("************************************************\n");
	      printf ("*** ERROR 02 ETH 1 ***  Cannot start ping    ***\n");
	      printf ("************************************************\n");
	      sleep (3);
	      exit (EXIT_FAILURE);
	    }


	}
      else
	{
	  sleep (3);
	  printf ("************************************************\n");
	  printf ("****      Starting Update Flash Process    *****\n");
	  printf ("************************************************\n");
	  sleep (3);
	}

      printf ("************************************************\n");
      printf ("**  Installing %s Firmware \n", mdl_msg.model);
      printf ("************************************************\n");
      sleep (3);
      sprintf(ubuf, "/prod/%s",mdl_msg.model);



      // ******************************************************************
      //  FLASH NAND FLASH WITH  UBOOT PARAMS, KERNEL AND FILE SYSTEM
      // ******************************************************************

      system ("flash_erase -q /dev/mtd0 0 0");
      system ("flash_erase -q /dev/mtd1 0 0");
      system ("flash_erase -q /dev/mtd2 0 0");
      strcpy (cbuf, "nandwrite -p -s 0x00000000 /dev/mtd1 ");
      strcat (cbuf, ubuf);
      strcat (cbuf, "/rootfs.arm_nofpu.jffs2");
      op_stat = WEXITSTATUS(system (cbuf));

      if(op_stat!= 0)
      {
	  printf ("************************************************\n");
	  printf ("*** ERROR 10 Nand erase or program failure   ***\n");
	  printf ("************************************************\n");
	  sleep (3);
	  exit (EXIT_FAILURE);
      }


      // ******************************************************************
      //  GO TO SERVER AND GET SERIAL NUMBER AN MAC ADDRESSES
      // ******************************************************************

      // But first see if we can mount the serial data flash
      if (system ("mount -t jffs2 /dev/mtdblock4 /mnt") != 0)
	{
	  printf ("************************************************\n");
	  printf ("*** ERROR 08 Cannot mount serial data flash  ***\n");
	  printf ("************************************************\n");
	  sleep (3);
	  exit (EXIT_FAILURE);
	}

      strcpy(cbuf, ubuf);
      strcat(cbuf,"/release_id");
      fd = open(cbuf, O_RDONLY);
      if(fd == -1)
      {
	  printf ("************************************************\n");
	  printf ("*** ERROR 11 Cannot find release ID file     ***\n");
	  printf ("************************************************\n");
	  sleep (3);
	  exit (EXIT_FAILURE);
      }

      get_value ("RELEASE", fd, mm.release, sizeof (mm.release));
      get_value ("MODEL", fd, mm.model, sizeof (mm.model));
      get_value ("TYPE", fd, mm.type, sizeof (mm.type));
      close(fd);

      strcpy(mm.board,  mdl_msg.board);

      fd = open ("/mnt/release_id", O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
      if (fd != -1)
	{
          write(fd, "RELEASE=\"",9);
          write(fd, mm.release, strlen(mm.release));
          write(fd,"\"\n", 2);

          write(fd, "MODEL=\"",7);
          write(fd, mm.model, strlen(mm.model));
          write(fd,"\"\n", 2);

          write(fd, "TYPE=\"",6);
          write(fd, mm.type, strlen(mm.type));
          write(fd,"\"\n", 2);

          write(fd, "BOARD=\"",7);
          write(fd, mm.board, strlen(mm.board));
          write(fd,"\"\n", 2);

          write(fd, "UPDATEGLB=\"0000\"\n", 17); 

          write(fd, "UPDATESEL=\"0000\"\n", 17); 

	  close (fd);
	}
      else
	{
          close(fd);
	  printf ("************************************************\n");
	  printf ("*** ERROR 12 Cannot create release ID file   ***\n");
	  printf ("************************************************\n");
	  sleep (3);
	  exit (EXIT_FAILURE);
	}


      mm.meidh[0] = 0;
      mm.meidd[0] = 0;
      mm.esnh[0] = 0;
      mm.esnd[0] = 0;
      mm.imeid[0] = 0;
      mm.rdomfg[0] = 0;
      mm.rdomdl[0] = 0;
      mm.rdofw[0] = 0;
      mm.rdoprl[0] = 0;

      if (mdl_msg.operation == mode_update)
	{
	  err = 1;
	  // Get current Eth0 mac
	  fd = open ("/mnt/mac.eth0", O_RDONLY);
	  if (fd != -1)
	    {
              read (fd, mm.mac, 5);
	      for (x = 0; x < 12;)
		{
		  read (fd, &mm.mac[x], 2);
		  x += 2;
		  if (x < 12)
		    read (fd, &mm.mac[x], 1);
		}
	      mm.mac[12] = 0;
	      close (fd);

	      // Get current Eth1 mac
	      fd = open ("/mnt/mac.eth1", O_RDONLY);
	      if (fd != -1)
		{
                  read (fd, mm.mac2, 5);
		  for (x = 0; x < 12;)
		    {
		      read (fd, &mm.mac2[x], 2);
		      x += 2;
		      if (x < 12)
			read (fd, &mm.mac2[x], 1);
		    }
		  mm.mac2[12] = 0;
		  close (fd);

		  // Get current serial number
		  fd = open ("/mnt/serno", O_RDONLY);
		  if (fd != -1)
		    {
		      read (fd, mm.sernum, 7);
		      read (fd, mm.sernum, 10);
		      mm.sernum[10] = 0;
		      close (fd);
		      err = 0;
		    }
		}
	    }
	  if (err)
	    {
	      printf ("************************************************\n");
	      printf ("*** ERROR 09 Cannot Update This Unit.        ***\n");
	      printf ("*** MAC And Serial Number Files Not Present. ***\n");
	      printf ("*** Please Run Complete Test and Reflash     ***\n");
	      printf ("************************************************\n");
	      sleep (3);
	      exit (EXIT_FAILURE);
	    }
	}
      sendto (UDP_fd, &mm, sizeof (mm), 0, (struct sockaddr *) &mac_server, sizeof (mac_server));
      for (x = 0, reply_len = -1; (x <= 5) && (reply_len == -1); x++)
	{
	  sleep (2);
	  from_len = sizeof (from_addr);
	  reply_len = recvfrom (UDP_fd, &mm, sizeof (mm), 0, (struct sockaddr *) &from_addr, &from_len);
	  if ((reply_len != sizeof(mm)) || (from_addr.sin_addr.s_addr != mac_server.sin_addr.s_addr))
	    reply_len = -1;
	}
      close (UDP_fd);
      if (reply_len == -1)
	{
	  printf ("************************************************\n");
	  printf ("*** ERROR 04 Cannot connect with MAC server  ***\n");
	  printf ("************************************************\n");
	  sleep (3);
	  exit (EXIT_FAILURE);
	}
      else
	{
	  if (mdl_msg.operation == mode_flash_and_test)
	    {
	      fd = open ("/mnt/mac.eth0", O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
	      if (fd != -1)
		{
		  write (fd, "MAC=\"", 5);
		  for (x = 0; x < 12; x += 2)
		    {
		      write (fd, &mm.mac[x], 2);
		      if (x == 10)
			write (fd, "\"", 1);
		      else
			write (fd, ":", 1);
		    }
		  write (fd, "\n", 1);
		  close (fd);

		}
	      else
		{
		  printf ("************************************************\n");
		  printf ("*** ERROR 05 Cannot create mac.eth0          ***\n");
		  printf ("************************************************\n");
		  sleep (3);
		  exit (EXIT_FAILURE);
		}

	      fd = open ("/mnt/mac.eth1", O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
	      if (fd != -1)
		{
		  write (fd, "MAC=\"", 5);
		  for (x = 0; x < 12; x += 2)
		    {
		      write (fd, &mm.mac2[x], 2);
		      if (x == 10)
			write (fd, "\"", 1);
		      else
			write (fd, ":", 1);
		    }
		  write (fd, "\n", 1);
		  close (fd);

		}
	      else
		{
		  printf ("************************************************\n");
		  printf ("*** ERROR 06 Cannot create mac.eth1          ***\n");
		  printf ("************************************************\n");
		  sleep (3);
		  exit (EXIT_FAILURE);
		}


	      fd = open ("/mnt/serno", O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
	      if (fd != -1)
		{
		  write (fd, "SERNO=\"", 7);
		  write (fd, mm.sernum, strlen (mm.sernum));
		  write (fd, "\"\n", 2);
		  close (fd);
		}
	      else
		{
		  printf ("************************************************\n");
		  printf ("*** ERROR 07 Cannot create serno file        ***\n");
		  printf ("************************************************\n");
		  sleep (3);
		  exit (EXIT_FAILURE);
		}
              sync();
              sleep(3);
	      printf ("************************************************\n");
	      printf ("*** SUCCESS *** Test & Configuration Complete **\n");
	      printf ("*** Please wait for unit to reboot and verify **\n");
	      printf ("*** that MAC addresses are set properly       **\n");
	      printf ("************************************************\n");
	      sleep (5);
	    }
	}
//      sync();
//      sleep(2);
//      system ("umount /mnt");
//      sync();
//      sleep(4);
      reboot (RB_AUTOBOOT);
    }
  exit (EXIT_SUCCESS);
}


//---------------------------------------------------------------------------
// Function to extract values from configuration files base on a key. 
// For instance,    Value="12345" 
// Key is the string defining the parameter (Value), src_fd is the file descriptor
// of an open file to be parsed, dest is the locatioin where the value will be 
// placed (will contain 12345) and max_len is the maximum allowed  length
// of the value (5). Return is zero for success  and non zero for error
//---------------------------------------------------------------------------

int
get_value (char *key, int src_fd, char *dest, int max_len)
{
  int status = 1;
  char file_data;
  char *key_index;
  ssize_t read_size;

  lseek (src_fd, 0, SEEK_SET);

  // Find key
  for (key_index = key, read_size = 1; (read_size != 0) && (*key_index != 0);)
    {
      read_size = read (src_fd, &file_data, 1);
      if ((*key_index != file_data) || (read_size == 0))
	key_index = key;
      else
	key_index++;
    }

  //Eliminate white space and header characters 
  while ((read_size != 0) && (status == 1))
    {
      read_size = read (src_fd, &file_data, 1);
      if (file_data == '\"')
	status = 0;
    }
  read_size = read (src_fd, &file_data, 1);

  //Extract key value
  for (; (file_data != '\"') && (read_size != 0) && (max_len != 1); dest++, max_len--)
    {
      *dest = file_data;
      read_size = read (src_fd, &file_data, 1);

    }
  *dest = 0;
  return (status);
}
