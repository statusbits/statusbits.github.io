#!/bin/sh

. $AXIS_TOP_DIR/.config || exit 1

cat <<EOF
FTP_ENABLED="yes"
VFTPD_OPTIONS="-r"
EOF

if [ "$AXIS_CONFIG_QOS" = "y" ] ; then
cat <<EOF
dscp=\`/etc/qos/qos.sh get dscp ftp_mgmt\`
if [ -n "\$dscp" ]; then
	VFTPD_OPTIONS="\$VFTPD_OPTIONS -q \$dscp -Q \$dscp"
fi
EOF
fi
